import { MODULE_ID } from "../core/constants.mjs";
import { getModuleSocket } from "../core/socket.mjs";
import {
  getItemImagePickerGmFolderPaths,
  isItemImagePickerUseGmFolderEnabled,
  isItemImagePickerUseStaFoldersEnabled,
} from "../core/settings.mjs";

const IMAGE_EXTENSIONS = /\.(?:png|jpe?g|webp|svg|gif|avif)$/i;
const STA_ICON_BASE_PATH = "systems/sta/assets/compendia/icons";
const STA_DAMAGE_CORE_FOLDER = `${STA_ICON_BASE_PATH}/damage-core`;
const STA_UTILS_IMAGE_BASE_PATH = "modules/sta-utils/assets/item-images";
const DEFAULT_ICON_FOLDER = "plain-core";

const ITEM_TYPE_ICON_FOLDERS = {
  log: ["plain-core"],
  milestone: ["plain-core"],
  item: ["items-core"],
  armor: ["items-core"],
  characterweapon: ["weapons-core"],
  characterweapon2e: ["weapons-core"],
  starshipweapon: ["starshipweapons-core"],
  starshipweapon2e: ["starshipweapons-core"],
  talent: ["talents-core"],
  focus: ["focuses-core"],
  trait: ["plain-core"],
  injury: [],
  smallcraftcontainer: ["systems/sta/assets/compendia/ships/starfleet"],
  value: ["values-core"],
};

const ITEM_TYPE_STA_UTILS_FOLDERS = {
  log: ["log"],
  milestone: ["milestones"],
  item: ["equipment"],
  armor: ["equipment"],
  characterweapon: ["weapons"],
  characterweapon2e: ["weapons"],
  starshipweapon: ["starship-weapons"],
  starshipweapon2e: ["starship-weapons"],
  talent: ["talents"],
  focus: ["focuses"],
  trait: ["traits"],
  injury: ["injuries"],
  smallcraftcontainer: ["smallcraft-containers"],
};

function _normalizePath(path) {
  return String(path ?? "")
    .trim()
    .replace(/\\+/g, "/")
    .replace(/(^|[^:])\/{2,}/g, "$1/");
}

function _getFilePickerClass() {
  // `.implementation` resolves to whatever FilePicker subclass hosts actually
  // configure (e.g. The Forge swaps in an Assets-Library-aware subclass);
  // the base class alone cannot browse those paths.
  const base = foundry.applications?.apps?.FilePicker ?? globalThis.FilePicker;
  return base?.implementation ?? base ?? null;
}

function _isImagePath(filePath) {
  return IMAGE_EXTENSIONS.test(String(filePath ?? ""));
}

function _basename(filePath) {
  const full = _normalizePath(filePath);
  const base = full.split("/").pop() ?? full;
  return base.replace(/\.[^.]+$/, "");
}

function _displayNameFromPath(filePath) {
  const base = _basename(filePath);
  let decoded = base;
  try {
    decoded = decodeURIComponent(base);
  } catch (_) {
    decoded = base;
  }
  return decoded.replace(/\+/g, " ").replace(/[-_]+/g, " ").trim();
}

function _stripItemTypePrefix(displayName, itemType) {
  const name = String(displayName ?? "").trim();
  const type = String(itemType ?? "")
    .trim()
    .toLowerCase();
  if (!name || !type) return name;

  const aliases = {
    log: ["log", "plain"],
    milestone: ["milestone", "plain"],
    item: ["item", "equipment"],
    armor: ["armor"],
    characterweapon: ["characterweapon", "character weapon", "weapon"],
    characterweapon2e: ["characterweapon", "character weapon", "weapon"],
    starshipweapon: ["starshipweapon", "starship weapon", "weapon"],
    starshipweapon2e: ["starshipweapon", "starship weapon", "weapon"],
    talent: ["talent"],
    focus: ["focus"],
    trait: ["trait", "plain"],
    injury: ["injury", "plain", "damage"],
    smallcraftcontainer: [
      "smallcraftcontainer",
      "small craft container",
      "smallcraft",
      "shuttlepod",
    ],
    value: ["value"],
  };

  const prefixes = aliases[type] ?? [type];
  const lowerName = name.toLowerCase();

  for (const prefix of prefixes) {
    const p = String(prefix).trim().toLowerCase();
    if (!p) continue;
    if (lowerName === p) continue;
    if (lowerName.startsWith(`${p} `)) {
      return name.slice(p.length).trim();
    }
  }

  return name;
}

function _getFoldersForItemType(itemType) {
  const key = String(itemType ?? "").toLowerCase();
  const hasMapping = Object.hasOwn(ITEM_TYPE_ICON_FOLDERS, key);
  const folders = hasMapping
    ? ITEM_TYPE_ICON_FOLDERS[key]
    : [DEFAULT_ICON_FOLDER];
  return folders.map((folder) => {
    const value = String(folder ?? "").trim();
    return value.includes("/") ? value : `${STA_ICON_BASE_PATH}/${value}`;
  });
}

function _resolveItemContext(itemOrType) {
  if (itemOrType && typeof itemOrType === "object") {
    return {
      itemType: String(itemOrType.type ?? "").toLowerCase(),
      parentActorType: String(itemOrType.parent?.type ?? "").toLowerCase(),
    };
  }

  return {
    itemType: String(itemOrType ?? "").toLowerCase(),
    parentActorType: "",
  };
}

function _getStaFoldersForItemContext(itemType, parentActorType) {
  const folders = _getFoldersForItemType(itemType);

  // Embedded ship/small-craft injuries should include STA damage-core icons.
  const isShipInjury =
    itemType === "injury" &&
    (parentActorType === "starship" || parentActorType === "smallcraft");
  if (isShipInjury && !folders.includes(STA_DAMAGE_CORE_FOLDER)) {
    folders.push(STA_DAMAGE_CORE_FOLDER);
  }

  return folders;
}

function _getStaUtilsFoldersForItemType(itemType) {
  const key = String(itemType ?? "").toLowerCase();
  const folders = ITEM_TYPE_STA_UTILS_FOLDERS[key] ?? [];
  return folders.map((folder) => `${STA_UTILS_IMAGE_BASE_PATH}/${folder}`);
}

async function _browseFolder(folderPath) {
  const FilePickerCls = _getFilePickerClass();
  if (!FilePickerCls?.browse) return [];

  // Resolve source/target directly rather than via `new FilePicker({ current })`:
  // that helper assumes a *file* path (it strips the last segment if it contains
  // a ".", mistaking folder names like "v1.2" for filenames) and falls back to
  // the unrelated global `LAST_BROWSED_DIRECTORY` on a falsy path.
  let source = "data";
  let target = folderPath;
  const options = {};

  const s3Match = FilePickerCls.matchS3URL?.(folderPath);
  if (s3Match) {
    source = "s3";
    target = s3Match.groups.key;
    options.bucket = s3Match.groups.bucket;
  }

  const files = [];
  const visited = new Set();

  async function browseTarget(currentTarget) {
    const normalizedTarget = _normalizePath(currentTarget);
    const visitKey = normalizedTarget.replace(/\/+$/, "");
    if (visited.has(visitKey)) return;
    visited.add(visitKey);

    let result;
    try {
      result = await FilePickerCls.browse(source, normalizedTarget, options);
    } catch (err) {
      console.warn(
        `${MODULE_ID} | Failed to browse folder "${normalizedTarget}"`,
        err,
      );
      return;
    }

    const resultFiles = Array.isArray(result?.files) ? result.files : [];
    files.push(...resultFiles.filter(_isImagePath).map(_normalizePath));

    const childFolders = Array.isArray(result?.dirs) ? result.dirs : [];
    for (const childFolder of childFolders) {
      await browseTarget(childFolder);
    }
  }

  await browseTarget(target);
  return files;
}

async function _listFoldersLocally(folderPaths) {
  const out = [];
  for (const folderPath of folderPaths) {
    const files = await _browseFolder(folderPath);
    out.push(...files);
  }
  return out;
}

async function _listFoldersAsGm(folderPaths) {
  const socket = getModuleSocket();
  if (!socket?.executeAsGM || game.user?.isGM) {
    return _listFoldersLocally(folderPaths);
  }

  try {
    const response = await socket.executeAsGM("listItemImageFiles", {
      folders: folderPaths,
    });
    const files = Array.isArray(response?.files) ? response.files : [];
    return files.filter(_isImagePath).map(_normalizePath);
  } catch (err) {
    console.warn(`${MODULE_ID} | GM folder listing RPC failed`, err);
    return _listFoldersLocally(folderPaths);
  }
}

function _buildEntries(paths, sourceLabel, itemType) {
  return paths.map((path) => {
    const name = _stripItemTypePrefix(_displayNameFromPath(path), itemType);
    return {
      path,
      name,
      sourceLabel,
      lcName: name.toLowerCase(),
    };
  });
}

export async function listItemImagesAsGM({ folders = [] } = {}) {
  const normalizedFolders = Array.from(
    new Set(folders.map(_normalizePath).filter(Boolean)),
  );
  const files = await _listFoldersLocally(normalizedFolders);
  return { files };
}

// Session-scoped: avoids re-scanning folders (slow on hosts like The Forge)
// every time the picker is opened. Keyed by the folders actually consulted,
// so it self-invalidates if the relevant settings change.
const _optionsCache = new Map();
const CACHE_TTL_MS = 5 * 60 * 1000;

function _finalizeEntries(entries) {
  const deduped = [];
  const seen = new Set();
  for (const entry of entries) {
    if (seen.has(entry.path)) continue;
    seen.add(entry.path);
    deduped.push(entry);
  }

  deduped.sort((a, b) => {
    const sourceSort = a.sourceLabel.localeCompare(b.sourceLabel);
    if (sourceSort !== 0) return sourceSort;
    return a.name.localeCompare(b.name);
  });

  return deduped;
}

/**
 * @param {Function} [onProgress] Called with the entries found so far after
 *   each folder group resolves, so the picker can populate before every
 *   group finishes loading.
 */
export async function loadItemImageOptions(itemOrType, onProgress) {
  const { itemType, parentActorType } = _resolveItemContext(itemOrType);

  const staFolders = isItemImagePickerUseStaFoldersEnabled()
    ? _getStaFoldersForItemContext(itemType, parentActorType)
    : [];
  const staUtilsFolders = isItemImagePickerUseStaFoldersEnabled()
    ? _getStaUtilsFoldersForItemType(itemType)
    : [];
  const gmFolders = isItemImagePickerUseGmFolderEnabled()
    ? getItemImagePickerGmFolderPaths(itemType).map(_normalizePath)
    : [];

  const cacheKey = JSON.stringify([
    itemType,
    parentActorType,
    staFolders,
    staUtilsFolders,
    gmFolders,
  ]);
  const cached = _optionsCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    onProgress?.(cached.entries);
    return cached.entries;
  }

  const entries = [];
  // Enumerate folder groups concurrently and paint each as it resolves, so a
  // slow source (e.g. a large GM folder on The Forge) doesn't delay the rest.
  const groups = [];
  if (staFolders.length) groups.push(["STA", staFolders]);
  if (staUtilsFolders.length) groups.push(["STA Utils", staUtilsFolders]);
  if (gmFolders.length) groups.push(["GM", gmFolders]);

  await Promise.all(
    groups.map(async ([label, folders]) => {
      const files = await _listFoldersAsGm(folders);
      entries.push(..._buildEntries(files, label, itemType));
      onProgress?.(_finalizeEntries(entries));
    }),
  );

  const finalized = _finalizeEntries(entries);
  _optionsCache.set(cacheKey, { entries: finalized, timestamp: Date.now() });
  return finalized;
}
