import { MODULE_ID } from "../core/constants.mjs";
import {
  ATTRIBUTE_KEYS,
  DISCIPLINE_KEYS,
  ATTRIBUTE_LABELS,
  DISCIPLINE_LABELS,
  MINOR_ATTR_CHIPS,
  NOTABLE_ATTR_CHIPS,
  MINOR_DISC_CHIPS,
  NOTABLE_DISC_CHIPS,
  INCIDENTAL_QUALITIES,
  QUICK_TEMPERAMENTS,
  QUICK_ROLES,
  EQUIPMENT_LOADOUTS,
  TALENT_TEMPLATES,
  getSpecialRulesPackConfigured,
  RANDOM_NAMES,
  RANDOM_ROLES,
  RANDOM_FOCUSES_FALLBACK,
  RANDOM_VALUES,
  loadSpeciesCatalog,
  loadEquipmentItems,
  loadSpecialRulesItems,
  loadFocusNames,
  loadValueNames,
  createNpcActor,
} from "./npc-builder-data.mjs";

const MINOR_STEPS = [
  "info",
  "attributes",
  "departments",
  "special-rules",
  "equipment",
];
const NOTABLE_STEPS = [
  "info",
  "attributes",
  "departments",
  "details",
  "special-rules",
  "equipment",
];
const INCIDENTAL_STEPS = ["info"];
const QUICK_STEPS = ["info", "temperament", "role-selection", "equipment"];

const fapi = foundry.applications.api;

export class NPCBuilderApp extends fapi.HandlebarsApplicationMixin(
  fapi.Application,
) {
  constructor(options = {}) {
    super(options);
    this._currentStep = "info";
    this._equipmentCacheLoaded = false;
    this._specialRulesCacheLoaded = false;
    this._speciesCatalogLoaded = false;
    this._focusCacheLoaded = false;
    this._valueCacheLoaded = false;
    this._specialRulePreviewUuid = null;
    this._specialRuleDescriptionCache = new Map();
    this._specialRuleDescriptionLoads = new Map();
    this._specialRuleRawDescriptionCache = new Map();
    this._wizardState = {
      name: "",
      npcType: "minor",
      species: "",
      isHybrid: false,
      hybridSpecies: "",
      role: "",
      incidentalQuality: "proficient",
      quickTemperament: null,
      quickNpcRole: null,
      attributes: Object.fromEntries(ATTRIBUTE_KEYS.map((k) => [k, null])),
      disciplines: Object.fromEntries(DISCIPLINE_KEYS.map((k) => [k, null])),
      focuses: ["", "", ""],
      value: "",
      speciesCatalog: [],
      selectedAttributeBonuses: [],
      selectedEquipment: [],
      equipmentItems: [],
      equipmentSearch: "",
      equipmentType: "all",
      selectedSpecialRules: [],
      specialRulesItems: [],
      specialRulesSearch: "",
      specialRulesNpcOnly: false,
      specialRulesRequirementsOnly: false,
      customTalents: [],
      focusNames: [],
      valueNames: [],
    };
  }

  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-npc-builder`,
    classes: ["sta-tracker-dialog", "sta-npc-builder"],
    position: { width: 560 },
    window: {
      icon: "fa-solid fa-user-plus",
      title: "NPC Builder",
    },
  };

  static PARTS = {
    main: {
      template: `modules/${MODULE_ID}/templates/npc-builder.hbs`,
      root: true,
    },
  };

  // ── Helpers ──────────────────────────────────────────────────────────────

  _getSteps() {
    switch (this._wizardState.npcType) {
      case "notable":
        return NOTABLE_STEPS;
      case "incidental":
        return INCIDENTAL_STEPS;
      case "quick":
        return QUICK_STEPS;
      default:
        return MINOR_STEPS;
    }
  }

  _getAvailableAttrChips() {
    const pool =
      this._wizardState.npcType === "notable"
        ? [...NOTABLE_ATTR_CHIPS]
        : [...MINOR_ATTR_CHIPS];
    for (const val of Object.values(this._wizardState.attributes)) {
      if (val !== null) {
        const idx = pool.indexOf(val);
        if (idx !== -1) pool.splice(idx, 1);
      }
    }
    return pool;
  }

  _getAvailableDiscChips() {
    const pool =
      this._wizardState.npcType === "notable"
        ? [...NOTABLE_DISC_CHIPS]
        : [...MINOR_DISC_CHIPS];
    for (const val of Object.values(this._wizardState.disciplines)) {
      if (val !== null) {
        const idx = pool.indexOf(val);
        if (idx !== -1) pool.splice(idx, 1);
      }
    }
    return pool;
  }

  _normalizeRequirementString(value) {
    return String(value ?? "")
      .trim()
      .toLowerCase();
  }

  _resolveAttributeKey(value) {
    const normalized = this._normalizeRequirementString(value);
    if (!normalized) return null;
    if (ATTRIBUTE_KEYS.includes(normalized)) return normalized;
    return (
      ATTRIBUTE_KEYS.find(
        (key) =>
          this._normalizeRequirementString(ATTRIBUTE_LABELS[key]) ===
          normalized,
      ) ?? null
    );
  }

  _resolveDisciplineKey(value) {
    const normalized = this._normalizeRequirementString(value);
    if (!normalized) return null;
    if (DISCIPLINE_KEYS.includes(normalized)) return normalized;
    return (
      DISCIPLINE_KEYS.find(
        (key) =>
          this._normalizeRequirementString(DISCIPLINE_LABELS[key]) ===
          normalized,
      ) ?? null
    );
  }

  _meetsSpecialRuleRequirement(item) {
    if (!item?.hasRequirement) return true;

    const requirements = Array.isArray(item?.requirements)
      ? item.requirements
      : [];
    if (!requirements.length) return true;

    const evaluateCategory = (entry) => {
      const category = this._normalizeRequirementString(entry?.category);
      const clauses = Array.isArray(entry?.clauses)
        ? entry.clauses.filter((clause) => String(clause?.value ?? "").trim())
        : [];
      if (!category || !clauses.length) return true;

      const opIsAnd = String(entry?.operator ?? "OR").toUpperCase() === "AND";

      const checks = clauses.map((clause) => {
        const required = this._normalizeRequirementString(clause?.value);
        if (!required) return true;

        switch (category) {
          case "attribute": {
            const key = this._resolveAttributeKey(required);
            if (!key) return false;
            const value = this._wizardState.attributes[key];
            if (value == null) return false;
            const minimum = Number.isFinite(Number(clause?.minimum))
              ? Number(clause.minimum)
              : null;
            return minimum == null ? true : value >= minimum;
          }
          case "discipline": {
            const key = this._resolveDisciplineKey(required);
            if (!key) return false;
            const value = this._wizardState.disciplines[key];
            if (value == null) return false;
            const minimum = Number.isFinite(Number(clause?.minimum))
              ? Number(clause.minimum)
              : null;
            return minimum == null ? true : value >= minimum;
          }
          case "species": {
            const selectedSpecies = [this._wizardState.species];
            if (this._wizardState.isHybrid)
              selectedSpecies.push(this._wizardState.hybridSpecies);
            const selected = selectedSpecies
              .map((species) => this._normalizeRequirementString(species))
              .filter(Boolean);
            if (!selected.length) return false;
            // Comma-separated species list: any listed species qualifies.
            const opts = String(required)
              .split(",")
              .map((s) => this._normalizeRequirementString(s))
              .filter(Boolean);
            return opts.some((opt) =>
              selected.some(
                (species) => species === opt || species.includes(opt),
              ),
            );
          }
          case "type": {
            const npcType = this._normalizeRequirementString(
              this._wizardState.npcType,
            );
            if (required === "npc") return npcType !== "";
            if (required === "character") return false;
            if (required === "starship") return false;
            return false;
          }
          case "systems":
            // Ship-system requirement — an NPC/character can never meet it.
            return false;
          default:
            return true;
        }
      });

      return opIsAnd ? checks.every(Boolean) : checks.some(Boolean);
    };

    return requirements.every((entry) => evaluateCategory(entry));
  }

  _canProceed() {
    const state = this._wizardState;
    switch (this._currentStep) {
      case "info":
        return true;
      case "attributes": {
        if (!ATTRIBUTE_KEYS.every((k) => state.attributes[k] !== null))
          return false;
        const _specEntry = state.speciesCatalog.find(
          (s) => s.name.toLowerCase() === state.species?.trim().toLowerCase(),
        );
        if (_specEntry && _specEntry.attributeBonuses === null)
          return state.selectedAttributeBonuses.length === 3;
        return true;
      }
      case "departments": {
        const pool =
          state.npcType === "notable" ? NOTABLE_DISC_CHIPS : MINOR_DISC_CHIPS;
        return (
          DISCIPLINE_KEYS.filter((k) => state.disciplines[k] !== null).length >=
          pool.length
        );
      }
      case "temperament":
        return state.quickTemperament !== null;
      case "role-selection":
        return state.quickNpcRole !== null;
      default:
        return true;
    }
  }

  // ── Context ───────────────────────────────────────────────────────────────

  async _prepareContext(_options) {
    const loads = [];
    if (!this._equipmentCacheLoaded)
      loads.push(
        loadEquipmentItems().then((v) => {
          this._wizardState.equipmentItems = v;
          this._equipmentCacheLoaded = true;
        }),
      );
    if (!this._specialRulesCacheLoaded)
      loads.push(
        loadSpecialRulesItems().then((v) => {
          this._wizardState.specialRulesItems = v;
          this._specialRulesCacheLoaded = true;
        }),
      );
    if (!this._speciesCatalogLoaded)
      loads.push(
        loadSpeciesCatalog().then((v) => {
          this._wizardState.speciesCatalog = v;
          this._speciesCatalogLoaded = true;
        }),
      );
    if (!this._focusCacheLoaded)
      loads.push(
        loadFocusNames().then((v) => {
          this._wizardState.focusNames = v;
          this._focusCacheLoaded = true;
        }),
      );
    if (!this._valueCacheLoaded)
      loads.push(
        loadValueNames().then((v) => {
          this._wizardState.valueNames = v;
          this._valueCacheLoaded = true;
        }),
      );
    if (loads.length) await Promise.all(loads);

    const state = this._wizardState;
    const steps = this._getSteps();
    const stepIndex = steps.indexOf(this._currentStep);
    const availableAttrChips = this._getAvailableAttrChips();
    const availableDiscChips = this._getAvailableDiscChips();

    const selectedSpeciesEntry = state.speciesCatalog.find(
      (s) => s.name.toLowerCase() === state.species?.trim().toLowerCase(),
    );
    const needsAttributeBonusSelection = !!(
      selectedSpeciesEntry && selectedSpeciesEntry.attributeBonuses === null
    );

    const specialRulesAvailable = getSpecialRulesPackConfigured();
    const searchQuery = state.specialRulesSearch.trim().toLowerCase();
    const filteredSpecialRulesItems = state.specialRulesItems.filter((item) => {
      if (searchQuery && !item.name.toLowerCase().includes(searchQuery)) {
        return false;
      }
      if (state.specialRulesNpcOnly && !item.isNpcType) {
        return false;
      }
      if (
        state.specialRulesRequirementsOnly &&
        !this._meetsSpecialRuleRequirement(item)
      ) {
        return false;
      }
      return true;
    });

    if (specialRulesAvailable && filteredSpecialRulesItems.length > 0) {
      const hasActivePreview = filteredSpecialRulesItems.some(
        (item) => item.uuid === this._specialRulePreviewUuid,
      );
      if (!hasActivePreview) {
        this._specialRulePreviewUuid = filteredSpecialRulesItems[0].uuid;
      }
    } else {
      this._specialRulePreviewUuid = null;
    }

    const specialRulesItems = filteredSpecialRulesItems.map((item) => ({
      ...item,
      previewActive: item.uuid === this._specialRulePreviewUuid,
    }));

    let specialRulePreview = null;
    if (
      this._currentStep === "special-rules" &&
      specialRulesAvailable &&
      this._specialRulePreviewUuid
    ) {
      const previewItem = specialRulesItems.find(
        (item) => item.uuid === this._specialRulePreviewUuid,
      );
      if (previewItem) {
        const description = await this._loadSpecialRuleDescription(
          previewItem.uuid,
        );
        specialRulePreview = {
          name: previewItem.name,
          img: previewItem.img,
          requirementLabel: previewItem.requirementLabel,
          description,
        };
      }
    }

    return {
      currentStep: this._currentStep,
      stepLabel: `Step ${stepIndex + 1} of ${steps.length}`,
      isFirstStep: stepIndex === 0,
      isLastStep: stepIndex === steps.length - 1,
      canProceed: this._canProceed(),
      stepPanels: {
        info: this._currentStep === "info",
        attributes: this._currentStep === "attributes",
        departments: this._currentStep === "departments",
        details: this._currentStep === "details",
        "special-rules": this._currentStep === "special-rules",
        equipment: this._currentStep === "equipment",
        temperament: this._currentStep === "temperament",
        "role-selection": this._currentStep === "role-selection",
      },
      // Info
      name: state.name,
      npcType: state.npcType,
      isMinor: state.npcType === "minor",
      isNotable: state.npcType === "notable",
      isIncidental: state.npcType === "incidental",
      isQuick: state.npcType === "quick",
      species: state.species,
      isHybrid: state.isHybrid,
      hybridSpecies: state.hybridSpecies,
      role: state.role,
      speciesList: state.speciesCatalog.map((s) => ({
        name: s.name,
        selected: s.name === state.species,
        hasTalent: s.talentUuid !== null || s.abilityName !== null,
      })),
      speciesFromCatalog: state.speciesCatalog.length > 0,
      // Incidental
      incidentalQualities: INCIDENTAL_QUALITIES.map((q) => ({
        ...q,
        selected: q.key === state.incidentalQuality,
      })),
      // Quick — Temperament
      quickTemperaments: QUICK_TEMPERAMENTS.map((t) => ({
        ...t,
        selected: t.key === state.quickTemperament,
        attributeRows: ATTRIBUTE_KEYS.map((k) => ({
          label: ATTRIBUTE_LABELS[k],
          value: t.attributes[k],
        })),
      })),
      // Quick — Role selection
      quickRoles: QUICK_ROLES.map((r) => ({
        ...r,
        selected: r.key === state.quickNpcRole,
        disciplineRows: DISCIPLINE_KEYS.map((k) => ({
          label: DISCIPLINE_LABELS[k],
          value: r.disciplines[k],
        })),
      })),
      // Attributes
      availableAttrChips,
      attrPoolEmpty: availableAttrChips.length === 0,
      showBonusColumn: selectedSpeciesEntry != null,
      needsAttributeBonusSelection,
      attributeSlots: ATTRIBUTE_KEYS.map((k) => {
        const fixedBonus = selectedSpeciesEntry?.attributeBonuses?.[k] ?? null;
        return {
          key: k,
          label: ATTRIBUTE_LABELS[k],
          value: state.attributes[k],
          fixedBonus,
          choiceBonus: needsAttributeBonusSelection
            ? {
                selected: state.selectedAttributeBonuses.includes(k),
                disabled:
                  !state.selectedAttributeBonuses.includes(k) &&
                  state.selectedAttributeBonuses.length >= 3,
              }
            : null,
        };
      }),
      // Disciplines
      availableDiscChips,
      discPoolEmpty: availableDiscChips.length === 0,
      disciplineSlots: DISCIPLINE_KEYS.map((k) => ({
        key: k,
        label: DISCIPLINE_LABELS[k],
        value: state.disciplines[k],
      })),
      // Details (notable)
      focusList: state.focuses.map((f, i) => ({ value: f, num: i + 1 })),
      value: state.value,
      hasFocusSuggestions: state.focusNames.length > 0,
      focusSuggestions: state.focusNames,
      hasValueSuggestions: state.valueNames.length > 0,
      valueSuggestions: state.valueNames,
      // Equipment
      equipmentAvailable: true,
      equipmentLoadouts: EQUIPMENT_LOADOUTS.map((loadout, i) => ({
        name: loadout.name,
        index: i,
        active: this._isLoadoutActive(
          loadout,
          state.equipmentItems,
          state.selectedEquipment,
        ),
      })),
      standardEquipmentItems: state.equipmentItems
        .filter((item) => item.standardOrder >= 0)
        .sort((a, b) => a.standardOrder - b.standardOrder)
        .map((item) => ({
          ...item,
          checked: state.selectedEquipment.includes(item.uuid),
        })),
      equipmentItems: state.equipmentItems
        .filter((item) => item.standardOrder < 0)
        .map((item) => ({
          ...item,
          checked: state.selectedEquipment.includes(item.uuid),
        })),
      equipmentSearch: state.equipmentSearch,
      equipmentType: state.equipmentType,
      // Special rules
      specialRulesAvailable,
      specialRulesItems,
      specialRulePreview,
      specialRulesSearch: state.specialRulesSearch,
      specialRulesNpcOnly: state.specialRulesNpcOnly,
      specialRulesRequirementsOnly: state.specialRulesRequirementsOnly,
      specialRulesTotalCount: state.specialRulesItems.length,
      hasSpecialRulesMatches: specialRulesItems.length > 0,
      talentTemplates: TALENT_TEMPLATES,
      customTalents: state.customTalents,
    };
  }

  async _loadSpecialRuleDescription(uuid) {
    if (!uuid)
      return '<p class="npc-builder-hint">No description available.</p>';
    if (this._specialRuleDescriptionCache.has(uuid)) {
      return this._specialRuleDescriptionCache.get(uuid);
    }
    if (this._specialRuleDescriptionLoads.has(uuid)) {
      return this._specialRuleDescriptionLoads.get(uuid);
    }

    const load = (async () => {
      let fallback =
        '<p class="npc-builder-hint">No description available.</p>';
      try {
        const item = await fromUuid(uuid);
        if (!item) return fallback;

        let rawDescription = this._extractSpecialRuleRawDescription(item);
        if (rawDescription.trim()) {
          this._specialRuleRawDescriptionCache.set(uuid, rawDescription);
        }
        if (!rawDescription.trim()) return fallback;

        const enriched =
          await foundry.applications.ux.TextEditor.implementation.enrichHTML(
            rawDescription,
            {
              async: true,
            },
          );
        return enriched || fallback;
      } catch (err) {
        console.warn(
          `${MODULE_ID} | NPC Builder: failed loading special rule description ${uuid}`,
          err,
        );
        return fallback;
      }
    })();

    this._specialRuleDescriptionLoads.set(uuid, load);
    const description = await load;
    this._specialRuleDescriptionLoads.delete(uuid);
    this._specialRuleDescriptionCache.set(uuid, description);
    return description;
  }

  _extractSpecialRuleRawDescription(item) {
    let rawDescription =
      foundry.utils.getProperty(item, "system.description.value") ??
      foundry.utils.getProperty(item, "system.description") ??
      item.description ??
      "";
    if (typeof rawDescription !== "string") {
      rawDescription = rawDescription?.value ?? "";
    }
    return String(rawDescription ?? "").trim();
  }

  async _loadSpecialRuleRawDescription(uuid) {
    if (!uuid) return "";
    if (this._specialRuleRawDescriptionCache.has(uuid)) {
      return this._specialRuleRawDescriptionCache.get(uuid);
    }

    try {
      const item = await fromUuid(uuid);
      if (!item) return "";
      const rawDescription = this._extractSpecialRuleRawDescription(item);
      this._specialRuleRawDescriptionCache.set(uuid, rawDescription);
      return rawDescription;
    } catch (err) {
      console.warn(
        `${MODULE_ID} | NPC Builder: failed loading special rule text ${uuid}`,
        err,
      );
      return "";
    }
  }

  // ── Render ────────────────────────────────────────────────────────────────

  render(...args) {
    this._syncFormToState();
    this._savedScrollPositions = this._captureScrollPositions();
    return super.render(...args);
  }

  _syncFormToState() {
    const html = this.element;
    if (!html) return;
    // Use the precise selector so the "Talent Preview" wrapper div (which also
    // carries .npc-custom-talent) is not counted as an index offset.
    html
      .querySelectorAll(".npc-custom-talent.npc-builder-field-row")
      .forEach((row, i) => {
        const talent = this._wizardState.customTalents[i];
        if (!talent) return;
        const nameEl = row.querySelector(".npc-custom-talent-name");
        const descEl = row.querySelector(".npc-custom-talent-desc");
        if (nameEl) talent.name = nameEl.value;
        if (descEl) talent.description = descEl.value;
      });
  }

  _captureScrollPositions() {
    const html = this.element;
    if (!html) return {};
    const positions = {};
    for (const el of html.querySelectorAll("*")) {
      if (el.scrollTop > 0) {
        const cls = el.classList[0];
        if (cls && !(cls in positions)) positions[cls] = el.scrollTop;
      }
    }
    return positions;
  }

  _restoreScrollPositions(positions) {
    const html = this.element;
    if (!html || !positions) return;
    for (const [cls, scrollTop] of Object.entries(positions)) {
      const el = html.querySelector(`.${CSS.escape(cls)}`);
      if (el) el.scrollTop = scrollTop;
    }
  }

  _onRender(context, options) {
    super._onRender(context, options);
    this._restoreScrollPositions(this._savedScrollPositions);
    this._savedScrollPositions = null;
    const html = this.element;

    html
      .querySelector(".npc-builder-back")
      ?.addEventListener("click", () => this._onBack());
    html.querySelector(".npc-builder-next")?.addEventListener("click", () => {
      if (this._canProceed()) this._onNext();
    });
    html
      .querySelector(".npc-builder-create")
      ?.addEventListener("click", () => this._onCreate());
    html
      .querySelector(".npc-builder-randomize")
      ?.addEventListener("click", () => this._onRandomize());

    switch (this._currentStep) {
      case "info":
        this._setupInfoStep(html);
        break;
      case "attributes":
        this._setupDragDrop(html, "attributes");
        this._setupAttributeBonusCheckboxes(html);
        break;
      case "departments":
        this._setupDragDrop(html, "disciplines");
        break;
      case "details":
        this._setupDetailsStep(html);
        break;
      case "special-rules":
        this._setupSpecialRulesStep(html);
        break;
      case "equipment":
        this._setupEquipmentStep(html);
        break;
      case "temperament":
        this._setupTemperamentStep(html);
        break;
      case "role-selection":
        this._setupRoleSelectionStep(html);
        break;
    }

    this._refreshNextButton(html);
  }

  _refreshNextButton(html = this.element) {
    const btn =
      html.querySelector(".npc-builder-next") ??
      html.querySelector(".npc-builder-create");
    if (btn) btn.disabled = !this._canProceed();
  }

  // ── Step setups ───────────────────────────────────────────────────────────

  _setupInfoStep(html) {
    const nameInput = html.querySelector("[name='npc-name']");
    if (nameInput) {
      nameInput.addEventListener("input", () => {
        this._wizardState.name = nameInput.value;
        this._refreshNextButton(html);
      });
    }

    for (const radio of html.querySelectorAll("[name='npcType']")) {
      radio.addEventListener("change", () => {
        const oldType = this._wizardState.npcType;
        this._wizardState.npcType = radio.value;
        // Reset chip assignments when pool sizes change
        if (oldType !== radio.value) {
          this._wizardState.attributes = Object.fromEntries(
            ATTRIBUTE_KEYS.map((k) => [k, null]),
          );
          this._wizardState.disciplines = Object.fromEntries(
            DISCIPLINE_KEYS.map((k) => [k, null]),
          );
          this._wizardState.quickTemperament = null;
          this._wizardState.quickNpcRole = null;
        }
        // Re-render so the footer (Next vs Create NPC) and conditional
        // info fields update correctly for the new type's step count.
        this.render();
      });
    }

    this._setupSpeciesCombobox(html, "species");
    if (this._wizardState.isHybrid)
      this._setupSpeciesCombobox(html, "hybridSpecies");
    html.querySelector("[name='isHybrid']")?.addEventListener("change", (e) => {
      this._wizardState.isHybrid = e.target.checked;
      this.render();
    });
    html.querySelector("[name='role']")?.addEventListener("input", (e) => {
      this._wizardState.role = e.target.value;
    });
    html
      .querySelector("[name='incidentalQuality']")
      ?.addEventListener("change", (e) => {
        this._wizardState.incidentalQuality = e.target.value;
      });

    // Per-field randomize buttons
    html
      .querySelector("[data-action='random-name']")
      ?.addEventListener("click", () => {
        this._wizardState.name = this._pick(RANDOM_NAMES);
        this.render();
      });

    html
      .querySelector("[data-action='random-species']")
      ?.addEventListener("click", () => {
        const catalog = this._wizardState.speciesCatalog;
        if (catalog.length > 0) {
          const picked = this._pick(catalog);
          this._wizardState.species = picked.name;
          this._wizardState.selectedAttributeBonuses = [];
        }
        this.render();
      });

    html
      .querySelector("[data-action='random-role']")
      ?.addEventListener("click", () => {
        this._wizardState.role = this._pick(RANDOM_ROLES);
        this.render();
      });

    html
      .querySelector("[data-action='random-quality']")
      ?.addEventListener("click", () => {
        this._wizardState.incidentalQuality =
          this._pick(INCIDENTAL_QUALITIES).key;
        this.render();
      });
  }

  _setupSpeciesCombobox(html, fieldName) {
    const input = html.querySelector(
      `.npc-species-combobox [name='${fieldName}']`,
    );
    // Plain text input (no catalog) — simple binding
    if (!input) {
      html
        .querySelector(`[name='${fieldName}']`)
        ?.addEventListener("input", (e) => {
          this._wizardState[fieldName] = e.target.value;
        });
      return;
    }

    const dropdown = input
      .closest(".npc-species-combobox")
      ?.querySelector(".npc-species-dropdown");
    if (!dropdown) return;
    const options = [...dropdown.querySelectorAll(".npc-species-option")];

    const showDropdown = () => {
      dropdown.classList.add("open");
      input.setAttribute("aria-expanded", "true");
    };
    const hideDropdown = () => {
      dropdown.classList.remove("open");
      input.setAttribute("aria-expanded", "false");
    };

    const filterOptions = (query) => {
      const q = query.trim().toLowerCase();
      for (const opt of options) {
        opt.hidden =
          q.length > 0 && !opt.dataset.value.toLowerCase().includes(q);
      }
    };

    const selectSpecies = (name) => {
      if (fieldName === "species" && this._wizardState.species !== name)
        this._wizardState.selectedAttributeBonuses = [];
      this._wizardState[fieldName] = name;
      input.value = name;
      filterOptions("");
      hideDropdown();
    };

    input.addEventListener("focus", () => {
      filterOptions(input.value);
      showDropdown();
    });

    input.addEventListener("input", () => {
      if (fieldName === "species" && this._wizardState.species !== input.value)
        this._wizardState.selectedAttributeBonuses = [];
      this._wizardState[fieldName] = input.value;
      filterOptions(input.value);
      showDropdown();
    });

    input.addEventListener("blur", () => {
      // Defer so a click on an option fires first
      setTimeout(hideDropdown, 150);
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        hideDropdown();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") showDropdown();
      const visible = options.filter((o) => !o.hidden);
      if (!visible.length) return;
      const active = dropdown.querySelector(".npc-species-option--active");
      let idx = visible.indexOf(active);
      if (e.key === "ArrowDown") {
        e.preventDefault();
        idx = Math.min(idx + 1, visible.length - 1);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        idx = Math.max(idx - 1, 0);
      } else if (e.key === "Enter" && active) {
        e.preventDefault();
        selectSpecies(active.dataset.value);
        return;
      } else {
        return;
      }
      for (const o of options) o.classList.remove("npc-species-option--active");
      visible[idx]?.classList.add("npc-species-option--active");
      visible[idx]?.scrollIntoView({ block: "nearest" });
    });

    for (const opt of options) {
      opt.addEventListener("mousedown", (e) => {
        e.preventDefault();
        selectSpecies(opt.dataset.value);
      });
      opt.addEventListener("mouseover", () => {
        for (const o of options)
          o.classList.remove("npc-species-option--active");
        opt.classList.add("npc-species-option--active");
      });
    }
  }

  _setupAttributeBonusCheckboxes(html) {
    for (const cb of html.querySelectorAll(".npc-bonus-attr-cb")) {
      cb.addEventListener("change", () => {
        const key = cb.value;
        const set = new Set(this._wizardState.selectedAttributeBonuses);
        if (cb.checked) {
          if (set.size < 3) set.add(key);
          else cb.checked = false;
        } else {
          set.delete(key);
        }
        this._wizardState.selectedAttributeBonuses = [...set];
        this.render();
      });
    }
  }

  _setupDetailsStep(html) {
    // Wire focus comboboxes
    html.querySelectorAll(".npc-focus-combobox").forEach((wrapper, i) => {
      this._setupSuggestionInput({
        input: wrapper.querySelector("input"),
        dropdown: wrapper.querySelector(".npc-suggestion-dropdown"),
        onChange: (val) => {
          this._wizardState.focuses[i] = val;
        },
      });
    });
    // Fallback plain inputs (no suggestions)
    html.querySelectorAll(".npc-focus-input").forEach((input, i) => {
      input.addEventListener("input", () => {
        this._wizardState.focuses[i] = input.value;
      });
    });
    // Wire value combobox
    const valWrapper = html.querySelector(".npc-value-combobox");
    if (valWrapper) {
      this._setupSuggestionInput({
        input: valWrapper.querySelector("input"),
        dropdown: valWrapper.querySelector(".npc-suggestion-dropdown"),
        onChange: (val) => {
          this._wizardState.value = val;
        },
      });
    } else {
      html.querySelector(".npc-value-input")?.addEventListener("input", (e) => {
        this._wizardState.value = e.target.value;
      });
    }

    // Per-field randomize buttons
    for (const btn of html.querySelectorAll("[data-action='random-focus']")) {
      btn.addEventListener("click", () => {
        const i = parseInt(btn.dataset.index);
        const pool =
          this._wizardState.focusNames.length > 0
            ? this._wizardState.focusNames
            : RANDOM_FOCUSES_FALLBACK;
        const used = this._wizardState.focuses.filter((_, j) => j !== i);
        const available = pool.filter((f) => !used.includes(f));
        this._wizardState.focuses[i] = this._pick(
          available.length > 0 ? available : pool,
        );
        this.render();
      });
    }

    html
      .querySelector("[data-action='random-value']")
      ?.addEventListener("click", () => {
        const pool =
          this._wizardState.valueNames.length > 0
            ? this._wizardState.valueNames
            : RANDOM_VALUES;
        this._wizardState.value = this._pick(pool);
        this.render();
      });
  }

  _setupSuggestionInput({ input, dropdown, onChange }) {
    if (!input) return;
    const options = dropdown
      ? [...dropdown.querySelectorAll(".npc-suggestion-option")]
      : [];

    const show = () => dropdown?.classList.add("open");
    const hide = () => dropdown?.classList.remove("open");

    const filter = (q) => {
      const lq = q.trim().toLowerCase();
      for (const opt of options)
        opt.hidden =
          lq.length > 0 && !opt.textContent.toLowerCase().includes(lq);
    };

    const select = (name) => {
      input.value = name;
      onChange(name);
      filter("");
      hide();
    };

    input.addEventListener("focus", () => {
      filter(input.value);
      show();
    });
    input.addEventListener("input", () => {
      onChange(input.value);
      filter(input.value);
      show();
    });
    input.addEventListener("blur", () => setTimeout(hide, 150));
    input.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        hide();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") show();
      const visible = options.filter((o) => !o.hidden);
      if (!visible.length) return;
      const active = dropdown.querySelector(".npc-species-option--active");
      let idx = visible.indexOf(active);
      if (e.key === "ArrowDown") {
        e.preventDefault();
        idx = Math.min(idx + 1, visible.length - 1);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        idx = Math.max(idx - 1, 0);
      } else if (e.key === "Enter" && active) {
        e.preventDefault();
        select(active.textContent.trim());
        return;
      } else return;
      for (const o of options) o.classList.remove("npc-species-option--active");
      visible[idx]?.classList.add("npc-species-option--active");
      visible[idx]?.scrollIntoView({ block: "nearest" });
    });

    for (const opt of options) {
      opt.addEventListener("mousedown", (e) => {
        e.preventDefault();
        select(opt.textContent.trim());
      });
      opt.addEventListener("mouseover", () => {
        for (const o of options)
          o.classList.remove("npc-species-option--active");
        opt.classList.add("npc-species-option--active");
      });
    }
  }

  _isLoadoutActive(loadout, equipmentItems, selectedEquipment) {
    const itemIds = (loadout.itemIds ?? [])
      .map((id) => String(id ?? "").trim())
      .filter(Boolean);
    const uuids = equipmentItems
      .filter((item) =>
        itemIds.some((id) => String(item?.uuid ?? "").endsWith(id)),
      )
      .map((item) => String(item?.uuid ?? ""))
      .filter(Boolean);
    return (
      uuids.length > 0 &&
      uuids.every((uuid) => selectedEquipment.includes(uuid))
    );
  }

  _setupEquipmentStep(html) {
    this._setupEquipmentFilters(html);
    const refreshLoadoutButtons = () => {
      for (const btn of html.querySelectorAll(".npc-loadout-btn")) {
        const loadout = EQUIPMENT_LOADOUTS[parseInt(btn.dataset.loadout)];
        if (!loadout) continue;
        const active = this._isLoadoutActive(
          loadout,
          this._wizardState.equipmentItems,
          this._wizardState.selectedEquipment,
        );
        btn.classList.toggle("active", active);
      }
    };

    for (const cb of html.querySelectorAll(".npc-equip-checkbox")) {
      cb.addEventListener("change", () => {
        const uuid = cb.value;
        const set = new Set(this._wizardState.selectedEquipment);
        if (cb.checked) set.add(uuid);
        else set.delete(uuid);
        this._wizardState.selectedEquipment = [...set];
        // Update loadout button states without a full re-render so the
        // scroll position is preserved.
        refreshLoadoutButtons();
      });
    }

    for (const btn of html.querySelectorAll(".npc-loadout-btn")) {
      btn.addEventListener("click", () => {
        const loadout = EQUIPMENT_LOADOUTS[parseInt(btn.dataset.loadout)];
        if (!loadout) return;
        const itemIds = (loadout.itemIds ?? [])
          .map((id) => String(id ?? "").trim())
          .filter(Boolean);
        const items = this._wizardState.equipmentItems;
        const uuids = items
          .filter((item) =>
            itemIds.some((id) => String(item?.uuid ?? "").endsWith(id)),
          )
          .map((item) => String(item?.uuid ?? ""))
          .filter(Boolean);
        const set = new Set(this._wizardState.selectedEquipment);
        const allSelected = uuids.every((uuid) => set.has(uuid));
        if (allSelected) {
          for (const uuid of uuids) set.delete(uuid);
        } else {
          for (const uuid of uuids) set.add(uuid);
        }
        this._wizardState.selectedEquipment = [...set];
        // Sync checkbox states and loadout buttons without a full re-render.
        for (const cb of html.querySelectorAll(".npc-equip-checkbox")) {
          cb.checked = this._wizardState.selectedEquipment.includes(cb.value);
        }
        refreshLoadoutButtons();
      });
    }
  }

  _setupEquipmentFilters(html) {
    const search = html.querySelector(".npc-equipment-search");
    const type = html.querySelector(".npc-equipment-type-filter");
    const applyFilter = () => {
      this._wizardState.equipmentSearch = search?.value ?? "";
      this._wizardState.equipmentType = type?.value ?? "all";
      const query = this._wizardState.equipmentSearch.trim().toLowerCase();
      const category = this._wizardState.equipmentType;
      for (const row of html.querySelectorAll(".npc-equip-item")) {
        const name = row.dataset.equipmentName ?? "";
        const matchesName = !query || name.includes(query);
        const matchesType =
          category === "all" || row.dataset.equipmentType === category;
        row.hidden = !matchesName || !matchesType;
      }
    };

    search?.addEventListener("input", applyFilter);
    type?.addEventListener("change", applyFilter);
    applyFilter();
  }

  _setupTemperamentStep(html) {
    for (const card of html.querySelectorAll(
      "[data-panel='temperament'] .npc-selection-card",
    )) {
      card.addEventListener("click", () => {
        const key = card.dataset.key;
        if (!key) return;
        this._wizardState.quickTemperament = key;
        this.render();
      });
    }
  }

  _setupRoleSelectionStep(html) {
    for (const card of html.querySelectorAll(
      "[data-panel='role-selection'] .npc-selection-card",
    )) {
      card.addEventListener("click", () => {
        const key = card.dataset.key;
        if (!key) return;
        this._wizardState.quickNpcRole = key;
        this.render();
      });
    }
  }

  _setupSpecialRulesStep(html) {
    const applySearchFilter = () => {
      const query = String(this._wizardState.specialRulesSearch ?? "")
        .trim()
        .toLowerCase();
      const rows = html.querySelectorAll(".npc-special-rule-row");
      let visibleCount = 0;
      for (const row of rows) {
        const name =
          row.querySelector(".npc-equip-name")?.textContent?.toLowerCase() ??
          "";
        const match = query.length === 0 || name.includes(query);
        row.hidden = !match;
        if (match) visibleCount += 1;
      }

      const noMatchesHint = html.querySelector(
        ".npc-special-rules-no-search-matches",
      );
      if (noMatchesHint) noMatchesHint.hidden = visibleCount > 0;
    };

    html
      .querySelector(".npc-special-rules-search")
      ?.addEventListener("input", (e) => {
        this._wizardState.specialRulesSearch = e.target.value;
        applySearchFilter();
      });

    applySearchFilter();

    html
      .querySelector(".npc-special-rules-filter-npc")
      ?.addEventListener("change", (e) => {
        this._wizardState.specialRulesNpcOnly = e.target.checked;
        this.render();
      });

    html
      .querySelector(".npc-special-rules-filter-requirements")
      ?.addEventListener("change", (e) => {
        this._wizardState.specialRulesRequirementsOnly = e.target.checked;
        this.render();
      });

    for (const row of html.querySelectorAll(".npc-special-rule-row")) {
      row.addEventListener("click", () => {
        const uuid = row.dataset.uuid;
        if (!uuid || uuid === this._specialRulePreviewUuid) return;
        this._specialRulePreviewUuid = uuid;
        this.render();
      });
    }

    for (const btn of html.querySelectorAll(".npc-special-rule-add-btn")) {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const uuid = btn.dataset.uuid;
        const name = btn.dataset.name || "Talent";
        if (!uuid) return;
        const description = await this._loadSpecialRuleRawDescription(uuid);
        this._wizardState.customTalents = [
          ...this._wizardState.customTalents,
          { name, description },
        ];
        this.render();
      });
    }

    for (const btn of html.querySelectorAll(".npc-talent-template-btn")) {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.templateIndex);
        const template = TALENT_TEMPLATES[idx];
        if (!template) return;
        this._wizardState.customTalents = [
          ...this._wizardState.customTalents,
          {
            name: template.name,
            description: template.description,
          },
        ];
        this.render();
      });
    }

    html
      .querySelector(".npc-custom-talent-add")
      ?.addEventListener("click", () => {
        this._wizardState.customTalents = [
          ...this._wizardState.customTalents,
          { name: "", description: "" },
        ];
        this.render();
      });

    for (const btn of html.querySelectorAll(".npc-custom-talent-remove")) {
      btn.addEventListener("click", () => {
        const idx = parseInt(btn.dataset.talentIndex);
        if (Number.isNaN(idx)) return;
        this._wizardState.customTalents =
          this._wizardState.customTalents.filter((_talent, i) => i !== idx);
        this.render();
      });
    }

    html
      .querySelectorAll(".npc-custom-talent.npc-builder-field-row")
      .forEach((row, i) => {
        row
          .querySelector(".npc-custom-talent-name")
          ?.addEventListener("input", (e) => {
            this._wizardState.customTalents[i].name = e.target.value;
          });
        row
          .querySelector(".npc-custom-talent-desc")
          ?.addEventListener("input", (e) => {
            this._wizardState.customTalents[i].description = e.target.value;
          });
      });
  }

  // ── Drag and drop ─────────────────────────────────────────────────────────

  _setupDragDrop(html, stateKey) {
    const pool = html.querySelector(".npc-chip-pool");

    const attachChipListeners = (chip) => {
      chip.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData(
          "text/plain",
          JSON.stringify({
            value: parseInt(chip.dataset.value),
            sourceKey: chip.dataset.sourceKey || null,
          }),
        );
        e.dataTransfer.effectAllowed = "move";
        chip.classList.add("dragging");
      });
      chip.addEventListener("dragend", () => chip.classList.remove("dragging"));
    };

    for (const chip of html.querySelectorAll(".npc-chip[draggable='true']")) {
      attachChipListeners(chip);
    }

    const attachZoneListeners = (zone, onDrop) => {
      zone.addEventListener("dragover", (e) => {
        e.preventDefault();
        zone.classList.add("drag-over");
      });
      zone.addEventListener("dragleave", () =>
        zone.classList.remove("drag-over"),
      );
      zone.addEventListener("drop", (e) => {
        e.preventDefault();
        zone.classList.remove("drag-over");
        const raw = e.dataTransfer.getData("text/plain");
        if (raw) onDrop(JSON.parse(raw));
      });
    };

    // Slot drop zones
    for (const zone of html.querySelectorAll(".npc-drop-zone")) {
      attachZoneListeners(zone, ({ value, sourceKey }) => {
        const targetKey = zone.dataset.key;
        const state = this._wizardState[stateKey];
        const existingValue = state[targetKey];
        // Clear source slot if dragging from a slot
        if (sourceKey !== null) state[sourceKey] = null;
        // Swap: send existing target value back to source slot
        if (existingValue !== null && sourceKey !== null)
          state[sourceKey] = existingValue;
        // Place value in target
        state[targetKey] = value;
        this.render();
      });
    }

    // Pool as drop target (return assigned chips)
    if (pool) {
      attachZoneListeners(pool, ({ sourceKey }) => {
        if (sourceKey !== null) {
          this._wizardState[stateKey][sourceKey] = null;
          this.render();
        }
      });
    }
  }

  // ── Navigation ────────────────────────────────────────────────────────────

  _shuffle(arr) {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  _pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  _onRandomize() {
    const state = this._wizardState;

    switch (this._currentStep) {
      case "info": {
        const prevType = state.npcType;
        state.name = this._pick(RANDOM_NAMES);
        const roll = Math.random();
        state.npcType =
          roll < 0.35
            ? "notable"
            : roll < 0.55
              ? "quick"
              : roll < 0.7
                ? "incidental"
                : "minor";
        state.species =
          state.speciesCatalog.length > 0
            ? this._pick(state.speciesCatalog).name
            : "";
        state.role = this._pick(RANDOM_ROLES);
        state.selectedAttributeBonuses = [];
        state.incidentalQuality = this._pick(INCIDENTAL_QUALITIES).key;
        if (prevType !== state.npcType) {
          state.attributes = Object.fromEntries(
            ATTRIBUTE_KEYS.map((k) => [k, null]),
          );
          state.disciplines = Object.fromEntries(
            DISCIPLINE_KEYS.map((k) => [k, null]),
          );
          state.quickTemperament = null;
          state.quickNpcRole = null;
        }
        break;
      }
      case "attributes": {
        const attrPool =
          state.npcType === "notable"
            ? [...NOTABLE_ATTR_CHIPS]
            : [...MINOR_ATTR_CHIPS];
        const attrKeys = this._shuffle(ATTRIBUTE_KEYS);
        state.attributes = Object.fromEntries(
          attrKeys.map((k, i) => [k, attrPool[i]]),
        );
        const entry = state.speciesCatalog.find(
          (s) => s.name.toLowerCase() === state.species?.trim().toLowerCase(),
        );
        if (entry?.attributeBonuses === null)
          state.selectedAttributeBonuses = this._shuffle(ATTRIBUTE_KEYS).slice(
            0,
            3,
          );
        break;
      }
      case "departments": {
        const discPool =
          state.npcType === "notable"
            ? [...NOTABLE_DISC_CHIPS]
            : [...MINOR_DISC_CHIPS];
        const discKeys = this._shuffle(DISCIPLINE_KEYS);
        state.disciplines = Object.fromEntries(
          DISCIPLINE_KEYS.map((k) => [k, null]),
        );
        for (let i = 0; i < discPool.length; i++)
          state.disciplines[discKeys[i]] = discPool[i];
        break;
      }
      case "details": {
        const focusPool = this._shuffle(
          state.focusNames.length > 0
            ? state.focusNames
            : RANDOM_FOCUSES_FALLBACK,
        );
        state.focuses = [focusPool[0], focusPool[1], focusPool[2]];
        const valuePool =
          state.valueNames.length > 0 ? state.valueNames : RANDOM_VALUES;
        state.value = this._pick(valuePool);
        break;
      }
      case "special-rules": {
        const talentCount = Math.floor(Math.random() * 3); // 0–2
        state.customTalents = this._shuffle(TALENT_TEMPLATES)
          .slice(0, talentCount)
          .map((talent) => ({
            name: talent.name,
            description: talent.description,
          }));
        state.selectedSpecialRules = [];
        break;
      }
      case "equipment": {
        const eqCount = 1 + Math.floor(Math.random() * 3); // 1–3
        state.selectedEquipment = this._shuffle(
          state.equipmentItems.map((i) => i.uuid),
        ).slice(0, eqCount);
        break;
      }
      case "temperament": {
        state.quickTemperament = this._pick(QUICK_TEMPERAMENTS).key;
        break;
      }
      case "role-selection": {
        state.quickNpcRole = this._pick(QUICK_ROLES).key;
        break;
      }
    }

    this.render();
  }

  _onBack() {
    const steps = this._getSteps();
    const idx = steps.indexOf(this._currentStep);
    if (idx > 0) {
      this._currentStep = steps[idx - 1];
      this.render();
    }
  }

  _onNext() {
    const steps = this._getSteps();
    const idx = steps.indexOf(this._currentStep);
    if (idx < steps.length - 1) {
      this._currentStep = steps[idx + 1];
      this.render();
    }
  }

  async _onCreate() {
    // Final capture of custom talent fields
    this.element?.querySelectorAll(".npc-custom-talent").forEach((row, i) => {
      this._wizardState.customTalents[i] = {
        name: row.querySelector(".npc-custom-talent-name")?.value ?? "",
        description: row.querySelector(".npc-custom-talent-desc")?.value ?? "",
      };
    });

    // Final capture of equipment checkboxes
    const checked = this.element?.querySelectorAll(
      ".npc-equip-checkbox:checked",
    );
    if (checked?.length) {
      this._wizardState.selectedEquipment = [...checked].map((cb) => cb.value);
    }

    const state = this._wizardState;

    // ── Incidental NPC ────────────────────────────────────────────────────
    if (state.npcType === "incidental") {
      const quality =
        INCIDENTAL_QUALITIES.find((q) => q.key === state.incidentalQuality) ??
        INCIDENTAL_QUALITIES[2];
      const attrs = Object.fromEntries(
        ATTRIBUTE_KEYS.map((k) => [k, quality.attribute]),
      );
      const discs = Object.fromEntries(
        DISCIPLINE_KEYS.map((k) => [k, quality.department]),
      );
      await createNpcActor({
        name: state.name,
        npcType: "minor",
        species: "",
        role: state.role,
        attributes: attrs,
        disciplines: discs,
        focuses: [],
        value: "",
        selectedEquipmentUuids: [],
        selectedSpecialRulesUuids: [],
        customTalents: [],
        speciesCatalog: [],
        selectedAttributeBonuses: [],
      });
      this.close();
      return;
    }

    // ── Quick NPC ─────────────────────────────────────────────────────────
    if (state.npcType === "quick") {
      const temperament =
        QUICK_TEMPERAMENTS.find((t) => t.key === state.quickTemperament) ??
        QUICK_TEMPERAMENTS[0];
      const quickRole =
        QUICK_ROLES.find((r) => r.key === state.quickNpcRole) ?? QUICK_ROLES[0];
      // Convert attributes object to the format createNpcActor expects
      // (it will add species bonuses on top)
      const attrs = { ...temperament.attributes };
      const discs = { ...quickRole.disciplines };
      await createNpcActor({
        name: state.name,
        npcType: "minor",
        species: state.species,
        isHybrid: state.isHybrid,
        hybridSpecies: state.hybridSpecies,
        role: state.role,
        attributes: attrs,
        disciplines: discs,
        focuses: [],
        value: "",
        selectedEquipmentUuids: state.selectedEquipment,
        selectedSpecialRulesUuids: [],
        customTalents: [],
        speciesCatalog: state.speciesCatalog,
        selectedAttributeBonuses: state.selectedAttributeBonuses,
      });
      this.close();
      return;
    }

    // ── Minor / Notable NPC (existing behaviour) ──────────────────────────
    await createNpcActor({
      name: state.name,
      npcType: state.npcType,
      species: state.species,
      isHybrid: state.isHybrid,
      hybridSpecies: state.hybridSpecies,
      role: state.role,
      attributes: state.attributes,
      disciplines: state.disciplines,
      focuses: state.focuses,
      value: state.value,
      selectedEquipmentUuids: state.selectedEquipment,
      selectedSpecialRulesUuids: [],
      customTalents: state.customTalents,
      speciesCatalog: state.speciesCatalog,
      selectedAttributeBonuses: state.selectedAttributeBonuses,
    });

    this.close();
  }
}
