/**
 * Star Trek Warp Speed Calculator
 *
 * Formula: v = w^(10/3) * c for warp 1-9
 * For warp > 9: v = w^(10/3 + (w-9)/(10-w)) * c
 * Constants:
 * - Speed of light (c) = 299,792.458 km/s
 * - 1 light-year = 9.461e12 km
 * - 1 day = 86,400 seconds
 */

import { MODULE_ID } from "../core/constants.mjs";
import { t } from "../core/i18n.mjs";

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

const SPEED_OF_LIGHT_KM_S = 299792.458; // km/s
const SECONDS_PER_DAY = 86400;
const KM_PER_LIGHT_YEAR = 9.461e12;

// Light-years per day at 1c
const LIGHT_YEARS_PER_DAY_AT_C =
  (SPEED_OF_LIGHT_KM_S * SECONDS_PER_DAY) / KM_PER_LIGHT_YEAR;
// ≈ 0.002738 ly/day (about 1 ly per 365.25 days)

function getConfiguredFormula() {
  try {
    return game.settings.get(MODULE_ID, "defaultWarpFormula") === "tos"
      ? "tos"
      : "tng";
  } catch (_) {
    return "tng";
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// TOS (ORIGINAL SERIES) WARP FORMULA
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Convert warp factor to speed using TOS formula.
 * Simple cubic relationship: v = w^3 * c
 * TOS allows warp factors beyond 10 (unlike TNG).
 *
 * @param {number} warpFactor - Warp factor (1.0 to 100.0)
 * @returns {number} Speed in multiples of c
 */
export function tosWarpToSpeedMultiplier(warpFactor) {
  if (warpFactor < 1) return warpFactor; // Sublight
  return Math.pow(warpFactor, 3);
}

/**
 * Convert speed back to warp factor using TOS formula.
 * Inverts: v = w^3, so w = v^(1/3)
 * TOS allows warp factors up to 100.
 *
 * @param {number} speedMultiplier - Speed in multiples of c
 * @returns {number|null} Warp factor, or null if invalid
 */
export function tosSpeedMultiplierToWarp(speedMultiplier) {
  if (speedMultiplier <= 0) return null;
  if (speedMultiplier < 1) return speedMultiplier;
  return Math.cbrt(speedMultiplier); // Cube root
}

// ─────────────────────────────────────────────────────────────────────────────
// TNG WARP FACTOR CONVERSION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Canonical TNG warp speed lookup table for warp 9+.
 * Format: [warpFactor, speedInC]
 */
const TNG_SPEED_TABLE = [
  [9.0, 1516.38],
  [9.1, 1575.51],
  [9.2, 1640.63],
  [9.3, 1713.31],
  [9.4, 1796.0],
  [9.5, 1894.85],
  [9.6, 2017.93],
  [9.7, 2185.45],
  [9.8, 2450.01],
  [9.9, 3029.26],
  [9.91, 3136.69],
  [9.92, 3264.3],
  [9.93, 3419.44],
  [9.94, 3613.71],
  [9.95, 3866.92],
  [9.96, 4216.18],
  [9.97, 4741.59],
  [9.98, 5660.62],
  [9.99, 7912.0],
];

/**
 * Find the speed using the TNG_SPEED_TABLE and linearly finding a midpoint between warp factors.
 * @param {number} warpFactor - Warp factor between 9.0 and 9.99
 * @returns {number} Speed in multiples of c
 */
function findSpeedAbove9(warpFactor) {
  // Find the two warp factors on either side of our input
  for (let i = 0; i < TNG_SPEED_TABLE.length - 1; i++) {
    const [w1, s1] = TNG_SPEED_TABLE[i];
    const [w2, s2] = TNG_SPEED_TABLE[i + 1];

    if (warpFactor >= w1 && warpFactor <= w2) {
      // Linear interpolation
      const t = (warpFactor - w1) / (w2 - w1);
      return s1 + t * (s2 - s1);
    }
  }

  // If above 9.99, extrapolate from last two points (approaches infinity)
  const [w1, s1] = TNG_SPEED_TABLE[TNG_SPEED_TABLE.length - 2];
  const [w2, s2] = TNG_SPEED_TABLE[TNG_SPEED_TABLE.length - 1];
  const t = (warpFactor - w1) / (w2 - w1);
  return s1 + t * (s2 - s1);
}

/**
 * Convert warp factor to speed as a multiple of c (speed of light).
 * Uses TNG-era formula.
 *
 * For warp 1-9: v = w^(10/3)
 * For warp 9+:  Uses lookup table with linear interpolation for accuracy
 *
 * @param {number} warpFactor - Warp factor (1.0 to 9.99)
 * @returns {number} Speed in multiples of c
 */
export function warpToSpeedMultiplier(warpFactor) {
  if (warpFactor < 1) return warpFactor; // Sublight
  if (warpFactor >= 10) return Infinity; // Warp 10 = infinite velocity

  if (warpFactor <= 9) {
    // Standard TNG formula: w^(10/3)
    return Math.pow(warpFactor, 10 / 3);
  } else {
    // Above warp 9: use lookup table for accuracy
    return findSpeedAbove9(warpFactor);
  }
}

/**
 * Convert speed (multiple of c) back to warp factor using Newton-Raphson iteration.
 * This inverts the TN-2 formula.
 *
 * @param {number} speedMultiplier - Speed in multiples of c
 * @returns {number|null} Warp factor, or null if invalid/unconverged
 */
export function speedMultiplierToWarp(speedMultiplier) {
  if (speedMultiplier <= 0) return null;
  if (speedMultiplier < 1) return speedMultiplier; // Sublight
  if (!isFinite(speedMultiplier)) return 10;

  const maxIterations = 50;
  const tolerance = 1e-9;

  // Function to minimize: f(w) = warpToSpeedMultiplier(w) - target
  const target = speedMultiplier;

  // Initial guess based on inverse of simple formula
  let w = Math.pow(target, 3 / 10);
  if (w > 9.99) w = 9.5; // Start in the correction zone

  for (let i = 0; i < maxIterations; i++) {
    const fw = warpToSpeedMultiplier(w) - target;

    if (Math.abs(fw) < tolerance) {
      return Math.min(Math.max(w, 1), 9.99);
    }

    // Numerical derivative
    const h = 1e-8;
    const fwh = warpToSpeedMultiplier(w + h) - target;
    const derivative = (fwh - fw) / h;

    if (Math.abs(derivative) < 1e-15) break;

    w = w - fw / derivative;

    // Clamp to valid range
    if (w < 1) w = 1;
    if (w > 9.999) w = 9.999;
  }

  // Return best estimate even if not fully converged
  return Math.min(Math.max(w, 1), 9.99);
}

// ─────────────────────────────────────────────────────────────────────────────
// CALCULATION FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Calculate distance traveled given warp factor and time (TNG formula).
 * @param {number} warpFactor - Warp factor (1-9.99)
 * @param {number} timeDays - Time in days
 * @returns {number} Distance in light-years
 */
export function calculateDistance(warpFactor, timeDays) {
  const speedC = warpToSpeedMultiplier(warpFactor);
  const lyPerDay = speedC * LIGHT_YEARS_PER_DAY_AT_C;
  return lyPerDay * timeDays;
}

/**
 * Calculate distance traveled given warp factor and time (TOS formula).
 * @param {number} warpFactor - Warp factor
 * @param {number} timeDays - Time in days
 * @returns {number} Distance in light-years
 */
function calculateDistanceTos(warpFactor, timeDays) {
  const speedC = tosWarpToSpeedMultiplier(warpFactor);
  const lyPerDay = speedC * LIGHT_YEARS_PER_DAY_AT_C;
  return lyPerDay * timeDays;
}

/**
 * Calculate time required given warp factor and distance (TNG formula).
 * @param {number} warpFactor - Warp factor (1-9.99)
 * @param {number} distanceLY - Distance in light-years
 * @returns {number} Time in days
 */
export function calculateTime(warpFactor, distanceLY) {
  const speedC = warpToSpeedMultiplier(warpFactor);
  const lyPerDay = speedC * LIGHT_YEARS_PER_DAY_AT_C;
  if (lyPerDay <= 0) return Infinity;
  return distanceLY / lyPerDay;
}

/**
 * Calculate time required given warp factor and distance (TOS formula).
 * @param {number} warpFactor - Warp factor
 * @param {number} distanceLY - Distance in light-years
 * @returns {number} Time in days
 */
function calculateTimeTos(warpFactor, distanceLY) {
  const speedC = tosWarpToSpeedMultiplier(warpFactor);
  const lyPerDay = speedC * LIGHT_YEARS_PER_DAY_AT_C;
  if (lyPerDay <= 0) return Infinity;
  return distanceLY / lyPerDay;
}

/**
 * Calculate warp factor required given distance and time (TNG formula).
 * @param {number} distanceLY - Distance in light-years
 * @param {number} timeDays - Time in days
 * @returns {number|null} Warp factor (1-9.99), or null if impossible
 */
export function calculateWarpFactor(distanceLY, timeDays) {
  if (timeDays <= 0) return null;
  const lyPerDay = distanceLY / timeDays;
  const speedC = lyPerDay / LIGHT_YEARS_PER_DAY_AT_C;
  return speedMultiplierToWarp(speedC);
}

/**
 * Calculate warp factor required given distance and time (TOS formula).
 * @param {number} distanceLY - Distance in light-years
 * @param {number} timeDays - Time in days
 * @returns {number|null} Warp factor, or null if impossible
 */
function calculateWarpFactorTos(distanceLY, timeDays) {
  if (timeDays <= 0) return null;
  const lyPerDay = distanceLY / timeDays;
  const speedC = lyPerDay / LIGHT_YEARS_PER_DAY_AT_C;
  return tosSpeedMultiplierToWarp(speedC);
}

// ─────────────────────────────────────────────────────────────────────────────
// FORMATTING HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Parse a travel duration into days. Plain numbers are days. Duration parts
 * accept abbreviated or written units in any order, plus hours:minutes.
 * @param {string|number} value
 * @returns {number|null}
 */
export function parseTravelTime(value) {
  const input = String(value ?? "")
    .trim()
    .toLowerCase();
  if (!input) return null;

  if (/^\d+(?:\.\d+)?$/.test(input)) {
    const days = Number(input);
    return Number.isFinite(days) && days > 0 ? days : null;
  }

  const duration = input.replace(/,/g, " ").replace(/\band\b/g, " ");
  const tokenPattern =
    /(?:(\d+(?:\.\d+)?)\s*(weeks?|w|days?|d|hours?|hrs?|hr|h|minutes?|mins?|min|m)|(\d+):([0-5]\d))/gy;
  let cursor = 0;
  let totalHours = 0;
  while (cursor < duration.length) {
    while (/\s/.test(duration[cursor] ?? "")) cursor += 1;
    if (cursor >= duration.length) break;

    tokenPattern.lastIndex = cursor;
    const match = tokenPattern.exec(duration);
    if (!match || match.index !== cursor) return null;
    cursor = tokenPattern.lastIndex;

    if (match[3] !== undefined) {
      totalHours += Number(match[3]) + Number(match[4]) / 60;
      continue;
    }

    const amount = Number(match[1]);
    const unit = match[2];
    if (unit.startsWith("w")) totalHours += amount * 7 * 24;
    else if (unit.startsWith("d")) totalHours += amount * 24;
    else if (unit.startsWith("h")) totalHours += amount;
    else totalHours += amount / 60;
  }
  if (totalHours <= 0) return null;
  return totalHours / 24;
}

/**
 * Format days as rounded whole weeks, days, and hours.
 * @param {number} days
 * @returns {string}
 */
export function formatTravelTime(days) {
  if (!Number.isFinite(days) || days <= 0) return "";
  let remainingHours = Math.max(1, Math.round(days * 24));
  const weeks = Math.floor(remainingHours / (7 * 24));
  remainingHours -= weeks * 7 * 24;
  const wholeDays = Math.floor(remainingHours / 24);
  const hours = remainingHours - wholeDays * 24;
  return [
    weeks ? `${weeks}w` : "",
    wholeDays ? `${wholeDays}d` : "",
    hours ? `${hours}h` : "",
  ]
    .filter(Boolean)
    .join(" ");
}

/**
 * Format a number with locale-aware formatting.
 * @param {number} value
 * @param {number} decimals
 * @returns {string}
 */
function formatNumber(value, decimals = 2) {
  if (!isFinite(value)) return "∞";
  return value.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

/**
 * Format time in days to a human-readable string (days + hours if applicable).
 * @param {number} days
 * @returns {string}
 */
function formatTime(days) {
  if (!isFinite(days)) return "∞";
  if (days < 1) {
    const hours = days * 24;
    return `${formatNumber(hours, 1)} hours`;
  }
  const wholeDays = Math.floor(days);
  const remainingHours = (days - wholeDays) * 24;
  if (remainingHours < 0.1) {
    return `${formatNumber(wholeDays, 0)} day${wholeDays !== 1 ? "s" : ""}`;
  }
  return `${formatNumber(wholeDays, 0)} day${wholeDays !== 1 ? "s" : ""}, ${formatNumber(remainingHours, 1)} hours`;
}

// ─────────────────────────────────────────────────────────────────────────────
// DIALOG UI (ApplicationV2 + HandlebarsApplicationMixin)
// ─────────────────────────────────────────────────────────────────────────────

const Base = foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2,
);

/**
 * Warp Speed Calculator Application.
 * Uses ApplicationV2 for real-time updates as the user types.
 */
class WarpCalculatorApp extends Base {
  constructor({ resolve = null } = {}, options = {}) {
    super(options);
    this._resolve = typeof resolve === "function" ? resolve : null;
    this._resolved = false;
    this._values = { warp: "", distance: "", time: "" };
    this._formulaType = getConfiguredFormula();
  }

  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-warp-calculator`,
    window: { title: "Warp Speed Calculator" },
    classes: ["sta-utils", "sta-warp-calculator-dialog", "sta-utils-ms-lcars"],
    position: { width: 400, height: "auto" },
    resizable: true,
  };

  static PARTS = {
    main: {
      template: `modules/${MODULE_ID}/templates/warp-calculator.hbs`,
    },
  };

  async _prepareContext(_options) {
    return {
      instructions: t("sta-utils.warpCalculator.instructions"),
      labels: {
        warpFactor: t("sta-utils.warpCalculator.warpFactor"),
        distance: t("sta-utils.warpCalculator.distance"),
        time: t("sta-utils.warpCalculator.time"),
        timePlaceholder: t("sta-utils.sidebar.widgets.warp.timePlaceholder"),
        lightYears: t("sta-utils.warpCalculator.lightYears"),
        days: t("sta-utils.warpCalculator.days"),
        enterTwoValues: t("sta-utils.warpCalculator.enterTwoValues"),
        sendToChat: t("sta-utils.warpCalculator.sendToChat"),
        close: t("sta-utils.warpCalculator.close"),
        formulaTng: t("sta-utils.warpCalculator.formulaTng"),
        formulaTos: t("sta-utils.warpCalculator.formulaTos"),
      },
      values: this._values,
      formulaType: this._formulaType,
    };
  }

  _resolveOnce(value) {
    if (this._resolved) return;
    this._resolved = true;
    try {
      this._resolve?.(value);
    } catch (err) {
      console.error(`${MODULE_ID} | WarpCalculatorApp resolve failed`, err);
    }
  }

  async close(options = {}) {
    this._resolveOnce(false);
    return super.close(options);
  }

  _attachPartListeners(partId, htmlElement, _options) {
    super._attachPartListeners?.(partId, htmlElement, _options);
    if (partId !== "main") return;

    const root = htmlElement;
    if (!root) return;

    // Prevent duplicate bindings on re-render
    if (root.dataset.staWarpCalcBound === "1") return;
    root.dataset.staWarpCalcBound = "1";

    const warpInput = root.querySelector('input[name="warp"]');
    const distanceInput = root.querySelector('input[name="distance"]');
    const timeInput = root.querySelector('input[name="time"]');
    const resultsDiv = root.querySelector('[data-hook="results"]');
    const sendButton = root.querySelector('button[data-action="send"]');
    const closeButton = root.querySelector('button[data-action="close"]');
    const formulaRadios = root.querySelectorAll('input[name="formula"]');

    const updateCalculation = () => {
      const warp = parseFloat(warpInput?.value) || null;
      const distance = parseFloat(distanceInput?.value) || null;
      const time = parseTravelTime(timeInput?.value);

      // Store values for potential re-render
      this._values = {
        warp: warpInput?.value ?? "",
        distance: distanceInput?.value ?? "",
        time: timeInput?.value ?? "",
      };

      const result = computeResults(warp, distance, time, this._formulaType);
      if (resultsDiv) resultsDiv.innerHTML = result.html;
      if (sendButton) sendButton.disabled = !result.valid;
    };

    // Bind input events for real-time updates
    warpInput?.addEventListener("input", updateCalculation);
    distanceInput?.addEventListener("input", updateCalculation);
    timeInput?.addEventListener("input", updateCalculation);

    // Bind formula selector radio buttons
    formulaRadios?.forEach((radio) => {
      radio.addEventListener("change", (ev) => {
        this._formulaType = ev.target.value;
        updateCalculation();
      });
    });

    // Handle button clicks
    sendButton?.addEventListener("click", async (ev) => {
      ev.preventDefault();
      const resultsHtml = resultsDiv?.innerHTML ?? "";
      sendResultsToChat(resultsHtml);
      this._resolveOnce(true);
      await this.close();
    });

    closeButton?.addEventListener("click", async (ev) => {
      ev.preventDefault();
      this._resolveOnce(false);
      await this.close();
    });

    // Copy button handler (event delegation — survives innerHTML replacement)
    resultsDiv?.addEventListener("click", (ev) => {
      const btn = ev.target.closest(".sta-copy-btn");
      if (!btn) return;
      const text =
        btn
          .closest(".sta-result-copy-group")
          ?.querySelector(".sta-warp-result-value")
          ?.textContent?.trim() ?? "";
      navigator.clipboard.writeText(text).catch(() => {});
      const icon = btn.querySelector("i");
      if (icon) {
        icon.className = "fas fa-check";
        btn.disabled = true;
        setTimeout(() => {
          icon.className = "fas fa-copy";
          btn.disabled = false;
        }, 1500);
      }
    });

    // Initial calculation
    updateCalculation();
  }
}

/**
 * Open the Warp Speed Calculator dialog.
 * Allows inputting any two values to calculate the third.
 * Results update in real-time as values change.
 *
 * @returns {Promise<boolean>} True if sent to chat, false if closed
 */
export async function openWarpCalculator() {
  return new Promise((resolve) => {
    const app = new WarpCalculatorApp({ resolve });
    app.render(true);
  });
}

/**
 * Calculate the missing trip value from any two supplied values.
 * @param {{warp?: number|null, distance?: number|null, time?: number|null, formulaType?: "tng"|"tos"}} values
 * @returns {{valid: boolean, status: "valid"|"insufficient"|"invalid", warp: number|null, distance: number|null, time: number|null, solveMode: "warp"|"distance"|"time"|"verify"|"", speedC: number|null, lyPerDay: number|null}}
 */
export function calculateWarpTrip({
  warp = null,
  distance = null,
  time = null,
  formulaType = "tng",
} = {}) {
  const normalizedFormula = formulaType === "tos" ? "tos" : "tng";
  const maxWarp = normalizedFormula === "tos" ? 100 : 9.99;
  const hasWarp = warp !== null && warp >= 1 && warp <= maxWarp;
  const hasDistance = distance !== null && distance > 0;
  const hasTime = time !== null && time > 0;
  const filledCount = [hasWarp, hasDistance, hasTime].filter(Boolean).length;

  if (filledCount < 2) {
    return {
      valid: false,
      status: "insufficient",
      warp,
      distance,
      time,
      solveMode: "",
      speedC: null,
      lyPerDay: null,
    };
  }

  const warpToSpeed =
    normalizedFormula === "tos"
      ? tosWarpToSpeedMultiplier
      : warpToSpeedMultiplier;
  const calcDistance =
    normalizedFormula === "tos" ? calculateDistanceTos : calculateDistance;
  const calcTime =
    normalizedFormula === "tos" ? calculateTimeTos : calculateTime;
  const calcWarp =
    normalizedFormula === "tos" ? calculateWarpFactorTos : calculateWarpFactor;

  let calculatedWarp = warp;
  let calculatedDistance = distance;
  let calculatedTime = time;
  let solveMode = "verify";

  if (hasWarp && hasTime && !hasDistance) {
    calculatedDistance = calcDistance(warp, time);
    solveMode = "distance";
  } else if (hasWarp && hasDistance && !hasTime) {
    calculatedTime = calcTime(warp, distance);
    solveMode = "time";
  } else if (hasDistance && hasTime && !hasWarp) {
    calculatedWarp = calcWarp(distance, time);
    solveMode = "warp";
  }

  const valid =
    calculatedWarp !== null &&
    Number.isFinite(calculatedWarp) &&
    calculatedDistance !== null &&
    Number.isFinite(calculatedDistance) &&
    calculatedTime !== null &&
    Number.isFinite(calculatedTime);
  if (!valid) {
    return {
      valid: false,
      status: "invalid",
      warp: calculatedWarp,
      distance: calculatedDistance,
      time: calculatedTime,
      solveMode,
      speedC: null,
      lyPerDay: null,
    };
  }

  const speedC = warpToSpeed(calculatedWarp);
  return {
    valid: true,
    status: "valid",
    warp: calculatedWarp,
    distance: calculatedDistance,
    time: calculatedTime,
    solveMode,
    speedC,
    lyPerDay: speedC * LIGHT_YEARS_PER_DAY_AT_C,
  };
}

/**
 * Compute results based on which two values are provided.
 * @param {number|null} warp
 * @param {number|null} distance
 * @param {number|null} time
 * @param {string} formulaType - 'tng' or 'tos'
 * @returns {{html: string, valid: boolean}}
 */
function computeResults(warp, distance, time, formulaType = "tng") {
  const result = calculateWarpTrip({ warp, distance, time, formulaType });
  if (result.status === "insufficient") {
    return {
      html: `<div class="sta-warp-result-placeholder">${t("sta-utils.warpCalculator.enterTwoValues")}</div>`,
      valid: false,
    };
  }
  if (!result.valid) {
    return {
      html: `<div class="sta-warp-result-error">${t("sta-utils.warpCalculator.cannotCalculate")}</div>`,
      valid: false,
    };
  }

  const warpDisplay = formatNumber(result.warp, 2);
  const distanceDisplay = formatNumber(result.distance, 2);
  const timeDisplay = formatTime(result.time);
  const lyPerDayDisplay = formatNumber(result.lyPerDay, 4);

  const highlightClass = (field) =>
    field === result.solveMode ? "sta-warp-calculated" : "";

  const html = `
    <div class="sta-warp-results-grid">
      <div class="sta-warp-result-row ${highlightClass("warp")}">
        <span class="sta-warp-result-label">${t("sta-utils.warpCalculator.warpFactor")}:</span>
        <span class="sta-result-copy-group">
          <span class="sta-warp-result-value">${warpDisplay}</span>
          <button class="sta-copy-btn" type="button" title="Copy"><i class="fas fa-copy"></i></button>
        </span>
      </div>
      <div class="sta-warp-result-row ${highlightClass("distance")}">
        <span class="sta-warp-result-label">${t("sta-utils.warpCalculator.distance")}:</span>
        <span class="sta-result-copy-group">
          <span class="sta-warp-result-value">${distanceDisplay} ${t("sta-utils.warpCalculator.ly")}</span>
          <button class="sta-copy-btn" type="button" title="Copy"><i class="fas fa-copy"></i></button>
        </span>
      </div>
      <div class="sta-warp-result-row ${highlightClass("time")}">
        <span class="sta-warp-result-label">${t("sta-utils.warpCalculator.time")}:</span>
        <span class="sta-result-copy-group">
          <span class="sta-warp-result-value">${timeDisplay}</span>
          <button class="sta-copy-btn" type="button" title="Copy"><i class="fas fa-copy"></i></button>
        </span>
      </div>
      <hr class="sta-warp-divider" />
      <div class="sta-warp-result-row sta-warp-derived">
        <span class="sta-warp-result-label">${t("sta-utils.warpCalculator.lyPerDay")}:</span>
        <span class="sta-result-copy-group">
          <span class="sta-warp-result-value">${lyPerDayDisplay} ${t("sta-utils.warpCalculator.lyDay")}</span>
          <button class="sta-copy-btn" type="button" title="Copy"><i class="fas fa-copy"></i></button>
        </span>
      </div>
    </div>
  `;

  return { html, valid: true };
}

/**
 * Send the calculated results to chat.
 * @param {string} resultsHtml - The HTML content of the results
 */
function sendResultsToChat(resultsHtml) {
  const content = `
    <div class="sta-utils-chat-card sta-utils-chat-card--blue">
      <h3><i class="fas fa-rocket"></i> ${t("sta-utils.warpCalculator.title")}</h3>
      ${resultsHtml}
    </div>
  `;

  ChatMessage.create({
    content,
    speaker: ChatMessage.getSpeaker(),
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS FOR API
// ─────────────────────────────────────────────────────────────────────────────

export const warpCalculator = {
  open: openWarpCalculator,
  warpToSpeedMultiplier,
  speedMultiplierToWarp,
  calculateDistance,
  calculateTime,
  calculateWarpFactor,
  calculateTrip: calculateWarpTrip,
  parseTravelTime,
  formatTravelTime,
};
