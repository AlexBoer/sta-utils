/**
 * Mission Pod Variants
 *
 * Lets a starship with a "Mission Pod" talent be linked to a set of sibling
 * starship actors representing pre-built loadout variants (one physical ship,
 * multiple mission-pod configurations). The "Sync Variants" button copies,
 * from the ship whose dialog is open to every other variant:
 *   - Systems/Departments base + advancement ratings. Each ship's rating is
 *     base + advancements + the bonus flags on its own Mission Pod talent;
 *     only the first two are shared, each variant re-applies its own pod bonus.
 *   - Talent, Trait, and Equipment items, unless individually flagged
 *     "Pod-Specific" (exempt) on the item's own sheet. Mission Pod talents
 *     themselves are never copied.
 * Nothing is synced automatically.
 *
 * A starship can belong to at most one variant group at a time.
 */

import { MODULE_ID } from "../core/constants.mjs";
import { getGroupShipActorId, setGroupShipActorId } from "../core/settings.mjs";

const Base = foundry.applications.api.HandlebarsApplicationMixin(
  foundry.applications.api.ApplicationV2,
);

const GROUP_FLAG = "missionPodGroupId";
const CURRENT_VARIANT_FLAG = "missionPodCurrentVariantId";
const TALENT_SYNC_FLAG = "missionPodSyncId";
const TALENT_EXEMPT_FLAG = "missionPodExempt";
const POD_BONUS_FLAG = "missionPodBonus";
const STAT_KEYS = {
  systems: [
    "communications",
    "computers",
    "engines",
    "sensors",
    "structure",
    "weapons",
  ],
  departments: [
    "command",
    "conn",
    "engineering",
    "medicine",
    "science",
    "security",
  ],
};
const ASSIGNED_SHIP_FLAG = "assignedShipUuid";
const MISSION_POD_TALENT_NAME = "mission pod";

/** Case-insensitive: any name containing "mission pod". */
function isMissionPodName(name) {
  return String(name ?? "")
    .toLowerCase()
    .includes(MISSION_POD_TALENT_NAME);
}
const TALENT_TYPES = ["talent", "shipTalent"];
// Item types that are mirrored across variants (unless individually exempt).
const SYNCED_ITEM_TYPES = [
  "talent",
  "shipTalent",
  "trait",
  "starshipweapon2e",
  "item",
];

let hooksInstalled = false;

// `key` must be the full dotted locale key (e.g. "sta-utils.missionPod.hint"),
// not a local suffix, so i18n Ally's regex-based key detection can resolve it.
function localize(key, fallback) {
  const value = game.i18n?.localize?.(key);
  return value && value !== key ? value : fallback;
}

function localizeFormat(key, data, fallback) {
  const value = game.i18n?.format?.(key, data);
  return value && value !== key ? value : fallback;
}

function escapeHtml(value) {
  return foundry.utils.escapeHTML(String(value ?? ""));
}

function normalize(name) {
  return String(name ?? "")
    .trim()
    .toLowerCase();
}

function allStarships() {
  return [...(game.actors ?? [])].filter((actor) => actor.type === "starship");
}

/* ------------------------------------------------------------------ */
/*  Group membership                                                   */
/* ------------------------------------------------------------------ */

export function getMissionPodGroupId(ship) {
  return String(ship?.getFlag?.(MODULE_ID, GROUP_FLAG) ?? "").trim();
}

export function getMissionPodVariants(ship) {
  const groupId = getMissionPodGroupId(ship);
  if (!groupId || !ship) return [];
  return allStarships()
    .filter((s) => s.id !== ship.id && getMissionPodGroupId(s) === groupId)
    .sort((a, b) => a.name.localeCompare(b.name));
}

function getMissionPodGroupMembers(ship) {
  return ship ? [ship, ...getMissionPodVariants(ship)] : [];
}

export function getMissionPodCurrentVariant(ship) {
  const members = getMissionPodGroupMembers(ship);
  if (!members.length) return null;
  const memberIds = new Set(members.map((member) => member.id));
  const configuredGroupShip = game.actors?.get?.(getGroupShipActorId());
  if (configuredGroupShip && memberIds.has(configuredGroupShip.id)) {
    return configuredGroupShip;
  }

  for (const member of members) {
    const currentId = String(
      member.getFlag?.(MODULE_ID, CURRENT_VARIANT_FLAG) ?? "",
    );
    if (memberIds.has(currentId)) {
      return members.find((candidate) => candidate.id === currentId) ?? null;
    }
  }

  return [...members].sort(
    (a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id),
  )[0];
}

async function setMissionPodCurrentVariant(ship, currentVariant) {
  const groupId = getMissionPodGroupId(ship);
  const members = getMissionPodGroupMembers(ship);
  if (
    !groupId ||
    !currentVariant ||
    !members.some((member) => member.id === currentVariant.id)
  ) {
    return false;
  }
  await Promise.all(
    members.map((member) =>
      member.setFlag(MODULE_ID, CURRENT_VARIANT_FLAG, currentVariant.id),
    ),
  );
  return true;
}

function getCanvasTokenDocument(app, actor) {
  return app?.token?.document ?? (actor?.isToken ? actor.token : null);
}

function getMissionPodTokenSwapContext(app, actor) {
  if (!game.user?.isGM || actor?.type !== "starship") return null;
  const token = getCanvasTokenDocument(app, actor);
  const scene = canvas.scene;
  const representedShip = token?.actorId
    ? game.actors?.get?.(token.actorId)
    : null;
  const groupId = getMissionPodGroupId(representedShip);
  const currentVariant = getMissionPodCurrentVariant(representedShip);

  if (
    !token ||
    !scene ||
    token.parent?.id !== scene.id ||
    !representedShip ||
    !groupId ||
    !currentVariant ||
    representedShip.id === currentVariant.id
  ) {
    return null;
  }
  return { currentVariant, groupId, scene };
}

async function reassignCanvasVariantTokens(app, actor) {
  const context = getMissionPodTokenSwapContext(app, actor);
  if (!context) return;

  const variantIds = new Set(
    allStarships()
      .filter((ship) => getMissionPodGroupId(ship) === context.groupId)
      .map((ship) => ship.id),
  );
  const updates = context.scene.tokens
    .filter(
      (token) =>
        variantIds.has(token.actorId) &&
        token.actorId !== context.currentVariant.id,
    )
    .map((token) => ({
      _id: token.id,
      actorId: context.currentVariant.id,
      actorLink: true,
      delta: null,
    }));

  if (!updates.length) {
    ui.notifications?.info?.(
      localize(
        "sta-utils.missionPod.noVariantTokens",
        "No other Mission Pod variant tokens on this scene.",
      ),
    );
  } else {
    try {
      await context.scene.updateEmbeddedDocuments("Token", updates);
      ui.notifications?.info?.(
        localizeFormat(
          "sta-utils.missionPod.tokensReassigned",
          { count: updates.length, name: context.currentVariant.name },
          `Reassigned ${updates.length} token(s) to ${context.currentVariant.name}.`,
        ),
      );
    } catch (error) {
      console.error(`${MODULE_ID} | Failed to reassign variant tokens`, error);
      ui.notifications?.error?.(
        localize(
          "sta-utils.missionPod.tokenReassignFailed",
          "Unable to reassign variant tokens.",
        ),
      );
      return;
    }
  }

  await app.close();
  await context.currentVariant.sheet?.render(true);
}

export function installMissionPodTokenSwapButton(app, root, actor) {
  const nameRow = root?.querySelector?.(
    ".top-right-column .name-row, .right-column .name-row",
  );
  if (!nameRow) return;

  const existing = nameRow.querySelector(".sta-lcars-mission-pod-token-swap");
  const context = getMissionPodTokenSwapContext(app, actor);
  if (!context) {
    existing?.remove();
    return;
  }
  if (existing) return;

  const button = document.createElement("button");
  button.type = "button";
  button.className = "sta-lcars-header-btn sta-lcars-mission-pod-token-swap";
  button.title = localize(
    "sta-utils.missionPod.reassignVariantTokens",
    "Reassign all Mission Pod variant tokens on this scene to this group's Current Variant",
  );
  button.setAttribute("aria-label", button.title);
  button.innerHTML = '<i class="fa-solid fa-shuffle" aria-hidden="true"></i>';
  button.addEventListener("click", async (event) => {
    event.preventDefault();
    event.stopPropagation();
    button.disabled = true;
    try {
      await reassignCanvasVariantTokens(app, actor);
    } finally {
      button.disabled = false;
    }
  });

  const linkButton = nameRow.querySelector(".sta-lcars-token-link-btn");
  if (linkButton) linkButton.insertAdjacentElement("afterend", button);
  else nameRow.appendChild(button);
}

/** Unset the group flag on any member left alone once a group shrinks to size 1. */
async function disbandIfLonely(groupId) {
  if (!groupId) return;
  const members = allStarships().filter(
    (s) => getMissionPodGroupId(s) === groupId,
  );
  if (members.length <= 1) {
    for (const member of members) {
      await member.unsetFlag(MODULE_ID, GROUP_FLAG).catch(() => {});
      await member.unsetFlag(MODULE_ID, CURRENT_VARIANT_FLAG).catch(() => {});
    }
  }
}

export async function addMissionPodVariant(ship, candidate) {
  if (!ship || !candidate || ship.id === candidate.id) return;
  let groupId = getMissionPodGroupId(ship);
  const currentVariant = getMissionPodCurrentVariant(ship) ?? ship;
  const previousGroupId = getMissionPodGroupId(candidate);
  if (previousGroupId && previousGroupId !== groupId) {
    await removeMissionPodVariant(candidate);
  }
  if (!groupId) {
    groupId = foundry.utils.randomID();
    await ship.setFlag(MODULE_ID, GROUP_FLAG, groupId);
  }
  await candidate.setFlag(MODULE_ID, GROUP_FLAG, groupId);
  await setMissionPodCurrentVariant(ship, currentVariant);
  await syncShipToVariants(ship, [candidate]);
}

export async function removeMissionPodVariant(ship) {
  const groupId = getMissionPodGroupId(ship);
  if (!groupId) return;
  const previousCurrent = getMissionPodCurrentVariant(ship);
  const remaining = getMissionPodVariants(ship);
  await ship.unsetFlag(MODULE_ID, GROUP_FLAG);
  await ship.unsetFlag(MODULE_ID, CURRENT_VARIANT_FLAG);
  await disbandIfLonely(groupId);
  if (remaining.length > 1) {
    const nextCurrent =
      previousCurrent?.id === ship.id
        ? [...remaining].sort(
            (a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id),
          )[0]
        : previousCurrent;
    if (nextCurrent)
      await setMissionPodCurrentVariant(remaining[0], nextCurrent);
  }
}

/* ------------------------------------------------------------------ */
/*  Talent exemption                                                    */
/* ------------------------------------------------------------------ */

export function isTalentMissionPodExempt(item) {
  // Mission Pod talents are always Pod-Specific.
  return (
    isMissionPodItem(item) ||
    Boolean(item?.getFlag?.(MODULE_ID, TALENT_EXEMPT_FLAG))
  );
}

/** Whether `actor` has a talent named "Mission Pod" (the trigger for pod-specific UI). */
export function actorHasMissionPodTalent(actor) {
  return (actor?.items ?? []).some(
    (i) => TALENT_TYPES.includes(i.type) && isMissionPodName(i.name),
  );
}

/** All of `actor`'s items (Talent/Trait/Equipment) flagged "Pod-Specific". */
function getPodSpecificItems(actor) {
  return (actor?.items ?? []).filter(
    (item) =>
      SYNCED_ITEM_TYPES.includes(item.type) && isTalentMissionPodExempt(item),
  );
}

/** Build the `data-tooltip-html` content for a variant's preview button. */
function buildPreviewTooltip(actor) {
  const description = escapeHtml(
    localize("sta-utils.missionPod.preview", "Module Preview:"),
  );
  const sections = [`<p>${description}</p>`];

  const bonus = getShipPodBonus(actor);
  const labelKeys = {
    systems: "sta.actor.starship.system.",
    departments: "sta.actor.starship.department.",
  };
  const bonusLines = [];
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    for (const key of keys) {
      const amount = bonus[group][key];
      if (!amount) continue;
      const sign = amount > 0 ? "+" : "";
      const label = game.i18n.localize(`${labelKeys[group]}${key}`);
      bonusLines.push(`<li>${escapeHtml(`${sign}${amount} ${label}`)}</li>`);
    }
  }
  if (bonusLines.length) {
    sections.push(
      `<p>${escapeHtml(localize("sta-utils.missionPod.podBonusesTitle", "Mission Pod bonuses"))}:</p><ul>${bonusLines.join("")}</ul>`,
    );
  }

  const podSpecific = getPodSpecificItems(actor);
  if (!podSpecific.length) {
    sections.push(
      `<p>${escapeHtml(localize("sta-utils.missionPod.noPodSpecificItems", "No Pod-Specific items."))}</p>`,
    );
  } else {
    const items = podSpecific
      .map((item) => `<li>${escapeHtml(item.name)}</li>`)
      .join("");
    sections.push(
      `<p>${escapeHtml(localize("sta-utils.missionPod.podSpecificItemsTitle", "Pod-Specific items"))}:</p><ul>${items}</ul>`,
    );
  }
  return sections.join("");
}

/* ------------------------------------------------------------------ */
/*  Mission Pod stat bonuses                                           */
/*  A ship's rating = base + advancements + its pod's bonus. Only the  */
/*  first two are shared between variants; the bonus lives in flags on */
/*  the Mission Pod talent and is applied per ship.                    */
/* ------------------------------------------------------------------ */

function isMissionPodItem(item) {
  return TALENT_TYPES.includes(item?.type) && isMissionPodName(item.name);
}

/** Read a Mission Pod talent's bonus flags as `{ systems: {key: n}, departments: {key: n} }`. */
function getPodBonusOf(item) {
  const raw = item?.getFlag?.(MODULE_ID, POD_BONUS_FLAG) ?? {};
  const bonus = {};
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    bonus[group] = {};
    for (const key of keys) {
      bonus[group][key] = Math.trunc(Number(raw?.[group]?.[key])) || 0;
    }
  }
  return bonus;
}

/** Total bonus from every Mission Pod talent on `actor`. */
function getShipPodBonus(actor) {
  const total = getPodBonusOf(null);
  for (const item of actor?.items ?? []) {
    if (!isMissionPodItem(item)) continue;
    const bonus = getPodBonusOf(item);
    for (const [group, keys] of Object.entries(STAT_KEYS)) {
      for (const key of keys) total[group][key] += bonus[group][key];
    }
  }
  return total;
}

/** `ship`'s Systems/Departments ratings with its own pod bonus removed. */
function getCoreStats(ship) {
  const bonus = getShipPodBonus(ship);
  const core = {};
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    core[group] = {};
    for (const key of keys) {
      const value = Number(ship.system?.[group]?.[key]?.value);
      core[group][key] =
        (Number.isFinite(value) ? value : 0) - bonus[group][key];
    }
  }
  return core;
}

/** Update payload setting `target` to `core` plus the target's own pod bonus. */
function buildStatsUpdate(core, target) {
  const bonus = getShipPodBonus(target);
  const update = {};
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    for (const key of keys) {
      update[`system.${group}.${key}.value`] =
        core[group][key] + bonus[group][key];
    }
  }
  return update;
}

/** Add `sign` times `bonus` to `actor`'s ratings (pod talent added, removed, or its bonus edited). */
async function applyPodBonus(actor, bonus, sign = 1) {
  const update = {};
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    for (const key of keys) {
      const amount = (bonus?.[group]?.[key] ?? 0) * sign;
      if (!amount) continue;
      const current = Number(actor.system?.[group]?.[key]?.value) || 0;
      update[`system.${group}.${key}.value`] = current + amount;
    }
  }
  if (Object.keys(update).length) await actor.update(update);
}

/**
 * One-way, on-demand sync from `source` to each target: Systems/Departments
 * base + advancement ratings (each target then adds its own Mission Pod
 * bonus) plus non-Pod-Specific Talent/Trait/Equipment items. Mission Pod
 * talents are never copied or pruned. With `prune`, target copies that no
 * longer exist on the source (or became Pod-Specific there) are deleted.
 * Nothing syncs automatically.
 */
async function syncShipToVariants(source, targets, { prune = false } = {}) {
  const coreStats = getCoreStats(source);

  const shared = [];
  for (const item of source.items) {
    if (!SYNCED_ITEM_TYPES.includes(item.type)) continue;
    if (isMissionPodItem(item)) continue;
    let syncId = item.getFlag(MODULE_ID, TALENT_SYNC_FLAG);
    if (isTalentMissionPodExempt(item)) {
      // Drop the stale link so copies made before it became Pod-Specific get pruned.
      if (syncId) await item.unsetFlag(MODULE_ID, TALENT_SYNC_FLAG);
      continue;
    }
    if (!syncId) {
      syncId = foundry.utils.randomID();
      await item.setFlag(MODULE_ID, TALENT_SYNC_FLAG, syncId);
    }
    shared.push({ item, syncId });
  }
  const sharedIds = new Set(shared.map((entry) => entry.syncId));
  const syncFlagPath = `flags.${MODULE_ID}.${TALENT_SYNC_FLAG}`;
  const typeAndName = (item) => `${item.type}:${normalize(item.name)}`;

  for (const target of targets) {
    try {
      await target.update(buildStatsUpdate(coreStats, target));

      const targetItems = target.items.filter(
        (item) =>
          SYNCED_ITEM_TYPES.includes(item.type) && !isMissionPodItem(item),
      );
      const bySyncId = new Map();
      const byTypeAndName = new Map();
      for (const item of targetItems) {
        const id = item.getFlag(MODULE_ID, TALENT_SYNC_FLAG);
        if (id) bySyncId.set(id, item);
        else byTypeAndName.set(typeAndName(item), item);
      }

      const toCreate = [];
      const toUpdate = [];
      for (const { item, syncId } of shared) {
        const existing =
          bySyncId.get(syncId) ?? byTypeAndName.get(typeAndName(item));
        if (existing && isTalentMissionPodExempt(existing)) continue;

        const data = item.toObject();
        if (!existing) {
          delete data._id;
          foundry.utils.setProperty(data, syncFlagPath, syncId);
          toCreate.push(data);
          continue;
        }
        toUpdate.push({
          _id: existing.id,
          name: data.name,
          img: data.img,
          system: data.system,
          [syncFlagPath]: syncId,
        });
      }

      const toDelete = prune
        ? [...bySyncId.entries()]
            .filter(
              ([id, item]) =>
                !sharedIds.has(id) && !isTalentMissionPodExempt(item),
            )
            .map(([, item]) => item.id)
        : [];

      if (toCreate.length) {
        await target.createEmbeddedDocuments("Item", toCreate);
      }
      if (toUpdate.length) {
        await target.updateEmbeddedDocuments("Item", toUpdate);
      }
      if (toDelete.length) {
        await target.deleteEmbeddedDocuments("Item", toDelete);
      }
    } catch (error) {
      console.warn(
        `${MODULE_ID} | Unable to sync mission pod data to "${target.name}"`,
        error,
      );
    }
  }
}

/**
 * Duplicate `ship` into a brand-new starship actor for use as another Mission
 * Pod loadout. The copy gets base + advancement ratings only (the source's pod
 * bonus is removed), no Mission Pod talent, and no Pod-Specific items; it
 * joins the same variant group.
 */
async function createShipVariant(ship) {
  const data = ship.toObject();
  delete data._id;
  data.name = localizeFormat(
    "sta-utils.missionPod.variantName",
    { name: ship.name },
    `${ship.name} (Variant)`,
  );
  data.items = (data.items ?? []).filter(
    (item) =>
      !foundry.utils.getProperty(
        item,
        `flags.${MODULE_ID}.${TALENT_EXEMPT_FLAG}`,
      ) && !(TALENT_TYPES.includes(item.type) && isMissionPodName(item.name)),
  );
  const core = getCoreStats(ship);
  for (const [group, keys] of Object.entries(STAT_KEYS)) {
    for (const key of keys) {
      foundry.utils.setProperty(
        data,
        `system.${group}.${key}.value`,
        core[group][key],
      );
    }
  }
  foundry.utils.setProperty(data, `flags.${MODULE_ID}.${GROUP_FLAG}`, null);

  const created = await Actor.create(data);
  if (!created) return null;
  await addMissionPodVariant(ship, created);
  return created;
}

/** Select a group's current variant, keeping the Group Ship setting in sync when applicable. */
async function selectAsCurrentVariant(groupMembers, newShip) {
  if (!newShip) return;
  const previousVariant = getMissionPodCurrentVariant(newShip);
  if (previousVariant?.id !== newShip.id) {
    await setMissionPodCurrentVariant(newShip, newShip);

    const groupShipId = getGroupShipActorId();
    if (groupMembers.some((member) => member.id === groupShipId)) {
      await setGroupShipActorId(newShip.id);
    }

    if (previousVariant) {
      const legacyNameIsUnique =
        allStarships().filter((ship) => ship.name === previousVariant.name)
          .length === 1;
      for (const character of game.actors ?? []) {
        if (character.type !== "character") continue;
        const assignedShipId = character.getFlag(MODULE_ID, ASSIGNED_SHIP_FLAG);
        const assignedById =
          assignedShipId === previousVariant.uuid ||
          assignedShipId === previousVariant.id;
        const assignedByLegacyName =
          !assignedShipId &&
          legacyNameIsUnique &&
          character.system?.assignment === previousVariant.name;
        if (!assignedById && !assignedByLegacyName) continue;

        try {
          await character.setFlag(MODULE_ID, ASSIGNED_SHIP_FLAG, newShip.uuid);
          await character.update({ "system.assignment": newShip.name });
        } catch (error) {
          console.warn(
            `${MODULE_ID} | Unable to reassign "${character.name}" to "${newShip.name}"`,
            error,
          );
        }
      }
    }
  }

  for (const member of groupMembers) {
    if (member.id === newShip.id) continue;
    if (member.sheet?.rendered) {
      await member.sheet.close().catch(() => {});
    }
  }
  await newShip.sheet?.render(true);
}

/* ------------------------------------------------------------------ */
/*  Manage Variants dialog                                             */
/* ------------------------------------------------------------------ */

class MissionPodVariantsDialog extends Base {
  constructor({ ship } = {}) {
    super();
    this.ship = ship;
  }

  static DEFAULT_OPTIONS = {
    id: `${MODULE_ID}-mission-pod-dialog`,
    classes: ["sta-utils", "sta-mission-pod-dialog"],
    window: {
      title: "Mission Pod Variants",
      icon: "fa-solid fa-shuffle",
    },
    position: { width: 440, height: "auto" },
    resizable: false,
  };

  static PARTS = {
    main: {
      template: `modules/${MODULE_ID}/templates/mission-pod-dialog.hbs`,
    },
  };

  get title() {
    return `${localize("sta-utils.missionPod.dialogTitle", "Mission Pod Variants")} — ${this.ship?.name ?? ""}`;
  }

  async _prepareContext() {
    const ship = this.ship;
    const groupId = getMissionPodGroupId(ship);
    const variants = getMissionPodVariants(ship);
    const memberIds = new Set([ship.id, ...variants.map((v) => v.id)]);
    const currentVariantId = getMissionPodCurrentVariant(ship)?.id;

    const candidates = allStarships()
      .filter((s) => !memberIds.has(s.id))
      .sort((a, b) => a.name.localeCompare(b.name))
      .map((s) => {
        const otherGroupId = getMissionPodGroupId(s);
        const inOtherGroup = Boolean(otherGroupId) && otherGroupId !== groupId;
        return {
          id: s.id,
          label: inOtherGroup
            ? localizeFormat(
                "sta-utils.missionPod.candidateInOtherGroup",
                { name: s.name },
                `${s.name} (currently in another group)`,
              )
            : s.name,
        };
      });

    return {
      ship: {
        id: ship.id,
        img: ship.img,
        name: ship.name,
        isCurrentVariant: ship.id === currentVariantId,
      },
      variants: variants.map((v) => ({
        id: v.id,
        img: v.img,
        name: v.name,
        isCurrentVariant: v.id === currentVariantId,
        previewTooltip: buildPreviewTooltip(v),
      })),
      candidates,
      hint: localize(
        "sta-utils.missionPod.hint",
        "Click Sync Variants to copy this ship's Systems, Departments, Equipment, Traits, and Talents to the other variants. Items marked as \u201cPod-Specific\u201d are not copied.",
      ),
      removeLabel: localize("sta-utils.missionPod.remove", "Remove from group"),
      noVariantsLabel: localize(
        "sta-utils.missionPod.noVariants",
        "No other variants yet.",
      ),
      choosePrompt: localize(
        "sta-utils.missionPod.choosePrompt",
        "Choose a starship...",
      ),
      addLabel: localize("sta-utils.missionPod.add", "Add Variant"),
      createVariantLabel: localize(
        "sta-utils.missionPod.createVariant",
        "Create New Ship Variant",
      ),
      syncLabel: localize("sta-utils.missionPod.sync", "Sync Variants"),
      syncTooltip: localize(
        "sta-utils.missionPod.syncTooltip",
        "Copies this ship's Systems, Departments, and non-Pod-Specific Talents, Traits, and Equipment to every other variant. Items removed or marked Pod-Specific here are removed from the variants.",
      ),
      hasVariants: variants.length > 0,
      swapPodLabel: localize("sta-utils.missionPod.swapPod", "Swap Pod"),
      swapPodTooltip: localize(
        "sta-utils.missionPod.swapPodTooltip",
        "Make this the Current Variant. Closes other variant sheets and opens this one.",
      ),
      currentVariantLabel: localize(
        "sta-utils.missionPod.currentVariant",
        "Current Variant",
      ),
    };
  }

  _attachPartListeners(partId, htmlElement, options) {
    super._attachPartListeners?.(partId, htmlElement, options);
    if (partId !== "main" || !htmlElement) return;
    if (htmlElement.dataset.missionPodBound === "1") return;
    htmlElement.dataset.missionPodBound = "1";

    const candidateSelect = htmlElement.querySelector(
      'select[name="candidateActorId"]',
    );
    const addVariantButton = htmlElement.querySelector(
      "[data-action='addVariant']",
    );
    candidateSelect?.addEventListener("change", () => {
      if (addVariantButton) addVariantButton.disabled = !candidateSelect.value;
    });

    htmlElement.addEventListener("click", async (event) => {
      const removeButton = event.target.closest(
        "[data-action='removeVariant']",
      );
      if (removeButton) {
        event.preventDefault();
        const member = game.actors?.get?.(removeButton.dataset.actorId);
        if (member) await removeMissionPodVariant(member);
        this.render();
        return;
      }

      const addButton = event.target.closest("[data-action='addVariant']");
      if (addButton) {
        event.preventDefault();
        const select = htmlElement.querySelector(
          'select[name="candidateActorId"]',
        );
        const candidate = game.actors?.get?.(select?.value ?? "");
        if (!candidate) return;
        await addMissionPodVariant(this.ship, candidate);
        ui.notifications?.info?.(
          localizeFormat(
            "sta-utils.missionPod.copiedAdvancements",
            { name: candidate.name },
            `Copied existing advancements to ${candidate.name}.`,
          ),
        );
        this.render();
        return;
      }

      const previewButton = event.target.closest(
        "[data-action='previewVariant']",
      );
      if (previewButton) {
        event.preventDefault();
        const variant = game.actors?.get?.(previewButton.dataset.actorId);
        await variant?.sheet?.render(true);
        return;
      }

      const selectCurrentVariantButton = event.target.closest(
        "[data-action='selectCurrentVariant']",
      );
      if (selectCurrentVariantButton) {
        event.preventDefault();
        if (selectCurrentVariantButton.disabled) return;
        const newShip = game.actors?.get?.(
          selectCurrentVariantButton.dataset.actorId,
        );
        if (!newShip) return;
        const groupMembers = [this.ship, ...getMissionPodVariants(this.ship)];
        await selectAsCurrentVariant(groupMembers, newShip);
        await this.close();
        return;
      }

      const syncButton = event.target.closest("[data-action='syncVariants']");
      if (syncButton) {
        event.preventDefault();
        syncButton.disabled = true;
        try {
          await syncShipToVariants(
            this.ship,
            getMissionPodVariants(this.ship),
            {
              prune: true,
            },
          );
          ui.notifications?.info?.(
            localizeFormat(
              "sta-utils.missionPod.synced",
              { name: this.ship.name },
              `Synced variants from ${this.ship.name}.`,
            ),
          );
        } finally {
          syncButton.disabled = false;
        }
        return;
      }

      const createVariantButton = event.target.closest(
        "[data-action='createVariant']",
      );
      if (createVariantButton) {
        event.preventDefault();
        createVariantButton.disabled = true;
        try {
          const created = await createShipVariant(this.ship);
          if (created) {
            ui.notifications?.info?.(
              localizeFormat(
                "sta-utils.missionPod.variantCreated",
                { name: created.name },
                `Created new variant "${created.name}".`,
              ),
            );
            await created.sheet?.render(true);
            this.render();
          }
        } finally {
          createVariantButton.disabled = false;
        }
      }
    });
  }
}

/* ------------------------------------------------------------------ */
/*  Talent row button injection                                        */
/* ------------------------------------------------------------------ */

// Font Awesome icon marking Pod-Specific item rows; change here to restyle.
const POD_SPECIFIC_ICON = "fa-solid fa-cube";

/** Add a hover-labelled marker to every Pod-Specific item row on the sheet. */
function installPodSpecificIcons(root, actor) {
  const podTalent = actor.items.find(
    (i) => TALENT_TYPES.includes(i.type) && isMissionPodName(i.name),
  );
  if (!podTalent) return;

  for (const row of root.querySelectorAll("li.row.entry[data-item-id]")) {
    if (row.querySelector("[data-sta-pod-specific-icon]")) continue;
    const item = actor.items.get(row.dataset.itemId);
    if (!item || !SYNCED_ITEM_TYPES.includes(item.type)) continue;
    if (!isTalentMissionPodExempt(item)) continue;

    const icon = document.createElement("span");
    icon.dataset.staPodSpecificIcon = "1";
    icon.className = "sta-pod-specific-icon";
    icon.dataset.tooltipText = podTalent.name;
    icon.setAttribute("aria-label", podTalent.name);
    icon.innerHTML = `<i class="${POD_SPECIFIC_ICON}" aria-hidden="true"></i>`;
    // Sibling of `.control`, which the LCARS theme hides.
    const anchor = row.querySelector(".control");
    if (anchor) anchor.insertAdjacentElement("beforebegin", icon);
    else row.appendChild(icon);
  }
}

export function installMissionPodTalentButton(root, actor) {
  if (!root || actor?.type !== "starship") return;
  installPodSpecificIcons(root, actor);
  if (!actor.isOwner) return;

  const rows = root.querySelectorAll(
    'li.row.entry[data-item-type="talent"], li.row.entry[data-item-type="shipTalent"]',
  );
  for (const row of rows) {
    if (row.querySelector("[data-sta-mission-pod-button]")) continue;
    const item = actor.items.get(row.dataset.itemId);
    if (!item || !isMissionPodName(item.name)) continue;

    const controls = row.querySelector(".control");
    if (!controls) continue;

    // The LCARS theme hides `div.control` entirely (right-click replaces
    // edit/delete), so this must be a sibling of it, not a child, to stay visible.
    const button = document.createElement("a");
    button.dataset.staMissionPodButton = "1";
    button.className = "mission-pod-variants control toggle";
    button.title = localize(
      "sta-utils.missionPod.manageVariants",
      "Manage Mission Pod Variants",
    );
    button.innerHTML = '<i class="fas fa-shuffle"></i>';
    button.addEventListener("click", (event) => {
      event.preventDefault();
      new MissionPodVariantsDialog({ ship: actor }).render(true);
    });
    controls.insertAdjacentElement("beforebegin", button);
  }
}

/* ------------------------------------------------------------------ */
/*  Item sheet — Mission Pod bonus fields (on the Mission Pod talent)    */
/* ------------------------------------------------------------------ */

function installPodBonusFields(root, item) {
  if (root.querySelector(".mission-pod-bonus-fields")) return;

  const bonus = getPodBonusOf(item);
  const groupTitles = {
    systems: localize("sta-utils.missionPod.bonusSystems", "Systems"),
    departments: localize(
      "sta-utils.missionPod.bonusDepartments",
      "Departments",
    ),
  };
  const labelKeys = {
    systems: "sta.actor.starship.system.",
    departments: "sta.actor.starship.department.",
  };

  const groupsHtml = Object.entries(STAT_KEYS)
    .map(([group, keys]) => {
      const rows = keys
        .map((key) => {
          const label = escapeHtml(
            game.i18n.localize(`${labelKeys[group]}${key}`),
          );
          return `<label class="mission-pod-bonus-row">
            <span>${label}</span>
            <input type="number" step="1" value="${bonus[group][key]}" data-group="${group}" data-key="${key}" />
          </label>`;
        })
        .join("");
      return `<div class="mission-pod-bonus-group">
        <div class="title">${escapeHtml(groupTitles[group])}</div>
        ${rows}
      </div>`;
    })
    .join("");

  const wrapper = document.createElement("div");
  wrapper.className = "mission-pod-bonus-fields";
  wrapper.innerHTML = `
    <div class="title">${escapeHtml(localize("sta-utils.missionPod.bonusTitle", "Mission Pod Bonuses"))}</div>
    <p class="hint">${escapeHtml(localize("sta-utils.missionPod.bonusHint", "Added to the ship's ratings when this talent is added to a ship. Not copied to other variants."))}</p>
    <div class="mission-pod-bonus-groups">${groupsHtml}</div>
  `;

  // Not named inputs on purpose: the sheet's own form must not submit these.
  wrapper.addEventListener("change", async (event) => {
    const input = event.target.closest("input[data-group][data-key]");
    if (!input) return;
    const { group, key } = input.dataset;
    const next = Math.trunc(Number(input.value)) || 0;
    input.value = next;

    const current = getPodBonusOf(item);
    const delta = next - current[group][key];
    if (!delta) return;
    current[group][key] = next;
    await item.setFlag(MODULE_ID, POD_BONUS_FLAG, current);

    const ship = item.parent;
    if (ship?.type === "starship") {
      await applyPodBonus(ship, { [group]: { [key]: delta } });
    }
  });

  const sheetBody =
    root.querySelector(".item-sheet") ??
    root.querySelector("[data-application-part='itemsheet']") ??
    root;
  sheetBody.appendChild(wrapper);
}

/* ------------------------------------------------------------------ */
/*  Item sheet — "Pod-Specific" exemption checkbox                      */
/*  Shown on Talent/Trait/Equipment item sheets, but only when the item */
/*  is embedded on a starship that has a "Mission Pod" talent.           */
/* ------------------------------------------------------------------ */

function installPodExemptCheckbox(root, item) {
  if (root.querySelector(".mission-pod-exempt-field")) return;

  const locked = isMissionPodItem(item);
  const lockedTooltip = locked
    ? ` data-tooltip-text="${escapeHtml(localize("sta-utils.missionPod.podAlwaysSpecific", "Mission Pod talents are always Pod-Specific."))}"`
    : "";
  const wrapper = document.createElement("div");
  wrapper.className = "row mission-pod-exempt-field";
  wrapper.innerHTML = `
    <label class="mission-pod-exempt-label"${lockedTooltip}>
      <input type="checkbox" class="mission-pod-exempt-toggle"${isTalentMissionPodExempt(item) ? " checked" : ""}${locked ? " disabled" : ""} />
      ${localize("sta-utils.missionPod.podSpecificLabel", "Pod-Specific (don't sync across Mission Pod variants)")}
    </label>
  `;

  wrapper
    .querySelector(".mission-pod-exempt-toggle")
    .addEventListener("change", (event) => {
      item.setFlag(MODULE_ID, TALENT_EXEMPT_FLAG, event.target.checked);
    });

  const sheetBody =
    root.querySelector(".item-sheet") ??
    root.querySelector("[data-application-part='itemsheet']") ??
    root;
  sheetBody.appendChild(wrapper);
}

/* ------------------------------------------------------------------ */
/*  Hooks                                                              */
/* ------------------------------------------------------------------ */

export function installMissionPodHooks() {
  if (hooksInstalled) return;
  hooksInstalled = true;

  Hooks.on("renderApplicationV2", (app, html) => {
    const item = app.document;
    if (!item || item.documentName !== "Item") return;
    if (isMissionPodItem(item)) {
      installPodExemptCheckbox(html, item);
      installPodBonusFields(html, item);
      return;
    }
    if (!SYNCED_ITEM_TYPES.includes(item.type)) return;
    if (item.parent?.type !== "starship") return;
    if (!actorHasMissionPodTalent(item.parent)) return;
    installPodExemptCheckbox(html, item);
  });

  // createX / deleteX fire as (document, options, userId); only the acting client applies the change.
  Hooks.on("createItem", async (item, _options, userId) => {
    if (userId !== game.user?.id) return;
    const ship = item.parent;
    if (ship?.type !== "starship" || !isMissionPodItem(item)) return;
    try {
      await applyPodBonus(ship, getPodBonusOf(item), 1);
    } catch (error) {
      console.warn(`${MODULE_ID} | Unable to apply Mission Pod bonus`, error);
    }
  });

  Hooks.on("deleteItem", async (item, _options, userId) => {
    if (userId !== game.user?.id) return;
    const ship = item.parent;
    if (ship?.type !== "starship" || !isMissionPodItem(item)) return;
    try {
      await applyPodBonus(ship, getPodBonusOf(item), -1);
    } catch (error) {
      console.warn(`${MODULE_ID} | Unable to remove Mission Pod bonus`, error);
    }
  });
}
