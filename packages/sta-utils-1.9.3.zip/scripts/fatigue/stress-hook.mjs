import { MODULE_ID } from "../core/constants.mjs";
import { ATTRIBUTE_LABELS } from "../core/gameConstants.mjs";

const FATIGUED_TRAIT_NAME = "Fatigued";
const FATIGUED_TRAIT_FLAG_KEY = "fatiguedTraitUuid";
const IS_FATIGUE_FLAG_KEY = "isFatigue";
const FATIGUED_ATTRIBUTE_FLAG_KEY = "fatiguedAttribute";
const ATTRIBUTE_TO_FATIGUED_NAME = {
  control: "Disordered (Fatigue)",
  daring: "Uncertain (Fatigue)",
  fitness: "Exhausted (Fatigue)",
  insight: "Confused (Fatigue)",
  presence: "Doubtful (Fatigue)",
  reason: "Insensible (Fatigue)",
};
// Reverse mapping for finding which attribute corresponds to a fatigued name
const FATIGUED_NAME_TO_ATTRIBUTE = Object.entries(
  ATTRIBUTE_TO_FATIGUED_NAME,
).reduce((acc, [key, value]) => {
  acc[value] = key;
  return acc;
}, {});
const FATIGUED_TRAIT_DESCRIPTION =
  "Fatigued: +1 difficulty on all task rolls. Additionally, all tasks using the chosen attribute automatically fail.";

let _staStressMonitoringHookInstalled = false;

// Per-actor lock to prevent concurrent create/delete operations
const _fatigueOperationInProgress = new Set();

/**
 * Shows a dialog for selecting which attribute caused the fatigue.
 * Updates the fatigued trait name based on the selected attribute.
 * @param {Item} traitItem - The Fatigued trait item
 * @param {Actor} actor - The character actor
 * @returns {void}
 */
export async function showAttributeSelectionDialog(traitItem, actor) {
  if (!traitItem || traitItem.type !== "trait") return;

  const buttons = [];

  // Create button for each attribute
  Object.entries(ATTRIBUTE_LABELS).forEach(([key, label]) => {
    buttons.push({
      action: key,
      label: label,
    });
  });

  const result = await foundry.applications.api.DialogV2.wait({
    window: {
      title: "Fatigued: Choose Attribute",
      icon: "fas fa-tired",
    },
    content: "<p>Choose which attribute your character is fatigued in:</p>",
    buttons: buttons,
    default: "control",
  });

  // If a valid attribute was selected, update the trait
  if (result && ATTRIBUTE_TO_FATIGUED_NAME[result]) {
    try {
      const newName = ATTRIBUTE_TO_FATIGUED_NAME[result];
      await traitItem.update({ name: newName });
      // Store which attribute is fatigued in the actor's system field
      if (actor) {
        await actor.update?.({ "system.fatiguedAttribute": result });
        // Deselect the fatigued attribute to prevent it from being permanently selected
        await actor.update({
          [`system.attributes.${result}.selected`]: false,
        });
      }
    } catch (err) {
      console.error(`${MODULE_ID} | Failed to update fatigued trait name`, err);
    }
  }
}

/**
 * Checks if a fatigued trait has had an attribute chosen.
 * Returns true if the attribute has been selected, false otherwise.
 * @param {Item} traitItem - The Fatigued trait item
 * @param {Actor} actor - The character actor
 * @returns {boolean}
 */
export function hasFatiguedAttributeChosen(traitItem, actor) {
  if (!traitItem || traitItem.type !== "trait") return false;
  try {
    // Check if actor has the fatiguedAttribute flag set
    const attr =
      actor?.system?.fatiguedAttribute ??
      actor?.getFlag?.(MODULE_ID, FATIGUED_ATTRIBUTE_FLAG_KEY) ??
      null;
    if (attr && ATTRIBUTE_TO_FATIGUED_NAME[attr]) return true;

    // Also check if the trait name matches one of the chosen attribute names
    const traitName = traitItem.name;
    if (Object.values(ATTRIBUTE_TO_FATIGUED_NAME).includes(traitName))
      return true;

    return false;
  } catch (_) {
    return false;
  }
}

/**
 * Finds an existing Fatigued trait on the actor.
 * First tries to find by stored ID in flags, then falls back to flag-based lookup.
 * @param {Actor} actor - The character actor
 * @returns {Item|null} The Fatigued trait item, or null if not found
 */
export function findFatiguedTrait(actor) {
  if (!actor?.items) return null;
  try {
    // First, try to find by ID stored in actor system field
    const storedId =
      actor.system?.fatiguedTraitUuid ??
      actor.getFlag?.(MODULE_ID, FATIGUED_TRAIT_FLAG_KEY) ??
      null;
    if (storedId) {
      const traitById = actor.items.get(storedId);
      if (traitById && traitById.type === "trait") return traitById;
      // ID didn't match; system field is stale, clear it asynchronously
      void actor.update?.({ "system.fatiguedTraitUuid": null });
    }

    // Fall back to system-field lookup: find any trait with isFatigue set to true
    const byFlag = Array.from(actor.items).find(
      (item) =>
        item?.type === "trait" &&
        (item.system?.isFatigue === true ||
          item.getFlag?.(MODULE_ID, IS_FATIGUE_FLAG_KEY) === true),
    );
    if (byFlag) return byFlag;

    // Final fallback: check for any trait whose name matches known fatigue names
    const knownNames = new Set([
      FATIGUED_TRAIT_NAME,
      ...Object.values(ATTRIBUTE_TO_FATIGUED_NAME),
    ]);
    return (
      Array.from(actor.items).find(
        (item) => item?.type === "trait" && knownNames.has(item.name),
      ) ?? null
    );
  } catch (_) {
    return null;
  }
}

/**
 * Gets the user who should handle fatigue for an actor.
 * Prefers the owning player if they're online, otherwise the first active GM.
 * @param {Actor} actor - The character actor
 * @returns {User|null} The user who should handle, or null if none
 */
function getUserToHandleFatigue(actor) {
  // Find the player who owns this character
  const owningPlayer = game.users?.find(
    (u) => !u.isGM && u.active && u.character?.id === actor.id,
  );
  if (owningPlayer) {
    return owningPlayer;
  }

  // Check if any player has ownership of this actor
  const playerOwners = game.users?.filter(
    (u) => !u.isGM && u.active && actor.testUserPermission?.(u, "OWNER"),
  );
  if (playerOwners?.length > 0) {
    const handler = playerOwners.sort((a, b) => a.id.localeCompare(b.id))[0];
    return handler;
  }

  // Fall back to first active GM
  const activeGMs = game.users?.filter((u) => u.isGM && u.active) ?? [];
  const gmHandler =
    activeGMs.sort((a, b) => a.id.localeCompare(b.id))[0] ?? null;
  return gmHandler;
}

/**
 * Checks if the current user should handle fatigue for the given actor.
 * @param {Actor} actor - The character actor
 * @returns {boolean}
 */
function shouldCurrentUserHandleFatigue(actor) {
  const handler = getUserToHandleFatigue(actor);
  return handler?.id === game.user?.id;
}

/**
 * Creates a new Fatigued trait on the actor and stores its ID in flags.
 * Shows an attribute selection dialog after creation.
 * @param {Actor} actor - The character actor
 * @returns {Promise<Item|null>} The newly created trait, or null if creation fails
 */
async function createFatiguedTrait(actor) {
  if (!actor?.createEmbeddedDocuments) return null;
  try {
    const [created] = await actor.createEmbeddedDocuments("Item", [
      {
        type: "trait",
        name: FATIGUED_TRAIT_NAME,
        system: {
          description: FATIGUED_TRAIT_DESCRIPTION,
        },
      },
    ]);

    if (!created) return null;

    // Store the ID in actor system field so we can find it even if renamed
    if (created.id) {
      await actor.update?.({ "system.fatiguedTraitUuid": created.id });
    }

    // Set the isFatigue field on the trait itself (must be done after creation)
    await created.update({ "system.isFatigue": true });

    // Note: Attribute selection is now done via a button on the character sheet
    // instead of auto-popping up a dialog.

    return created;
  } catch (err) {
    console.error(`${MODULE_ID} | createFatiguedTrait failed`, err);
    return null;
  }
}

/**
 * Deletes the Fatigued trait from the actor and clears the UUID flag.
 * @param {Actor} actor - The character actor
 * @param {Item} traitItem - The Fatigued trait item to delete
 * @returns {Promise<void>}
 */
async function deleteFatiguedTrait(actor, traitItem) {
  if (!actor?.deleteEmbeddedDocuments) return;
  try {
    // Resolve the current embedded Item id on the actor. The passed traitItem
    // may be stale or come from a different document instance, so prefer the
    // actor's live collection.
    let idToDelete = null;

    if (traitItem?.id && actor.items.get(traitItem.id)) {
      idToDelete = traitItem.id;
    } else if (traitItem?.uuid) {
      const byUuid = actor.items.find((i) => i?.uuid === traitItem.uuid);
      if (byUuid) idToDelete = byUuid.id;
    }

    // As a final fallback, find any trait on the actor marked with the
    // IS_FATIGUE_FLAG_KEY flag.
    if (!idToDelete) {
      const flagged = Array.from(actor.items).find(
        (i) =>
          i?.type === "trait" &&
          (i.system?.isFatigue === true ||
            i.getFlag?.(MODULE_ID, IS_FATIGUE_FLAG_KEY) === true),
      );
      if (flagged) idToDelete = flagged.id;
    }

    // If nothing found, clear system fields and return gracefully.
    if (!idToDelete) {
      await actor.update?.({
        "system.fatiguedTraitUuid": null,
        "system.fatiguedAttribute": null,
      });
      return;
    }

    await actor.deleteEmbeddedDocuments("Item", [idToDelete]);
    // Clear the stored ID and fatigued attribute
    await actor.update?.({
      "system.fatiguedTraitUuid": null,
      "system.fatiguedAttribute": null,
    });
  } catch (err) {
    console.warn(`${MODULE_ID} | deleteFatiguedTrait failed`, err);
  }
}

/**
 * Deletes ALL traits with the isFatigue flag from the actor.
 * This guards against orphaned fatigue traits.
 * @param {Actor} actor - The character actor
 * @returns {Promise<void>}
 */
async function deleteAllFatigueTraits(actor) {
  if (!actor?.deleteEmbeddedDocuments) return;
  try {
    // Find ALL traits with isFatigue set
    const fatigueTraits = actor.items.filter(
      (i) =>
        i?.type === "trait" &&
        (i.system?.isFatigue === true ||
          i.getFlag?.(MODULE_ID, IS_FATIGUE_FLAG_KEY) === true),
    );

    if (fatigueTraits.length === 0) {
      // No fatigue traits, just clear the actor system fields
      await actor.update?.({
        "system.fatiguedTraitUuid": null,
        "system.fatiguedAttribute": null,
      });
      return;
    }

    // Delete all fatigue traits at once
    const idsToDelete = fatigueTraits.map((t) => t.id);
    await actor.deleteEmbeddedDocuments("Item", idsToDelete);

    // Clear the stored system fields
    await actor.update?.({
      "system.fatiguedTraitUuid": null,
      "system.fatiguedAttribute": null,
    });
  } catch (err) {
    console.warn(`${MODULE_ID} | deleteAllFatigueTraits failed`, err);
  }
}

/**
 * Checks if the current user can modify the actor (for stress trait management).
 * @param {Actor} actor - The character actor
 * @returns {boolean} True if the user can write to the actor
 */
function canWriteActor(actor) {
  try {
    return (
      game.user?.isGM === true ||
      actor?.isOwner === true ||
      (typeof actor?.testUserPermission === "function" &&
        actor.testUserPermission(game.user, "OWNER"))
    );
  } catch (_) {
    return false;
  }
}

/**
 * Checks if an actor should experience fatigue mechanics.
 * NPCs on the NPC or NPC-LCARS sheet, and characters with stress.max = 0, do not experience fatigue.
 * @param {Actor} actor - The character actor
 * @returns {boolean} True if the actor can experience fatigue
 */
function canExperienceFatigue(actor) {
  try {
    // NPCs on the NPC or NPC LCARS sheet do not experience fatigue.
    // Use both explicit sheetClass flag and runtime sheet class/name so this still
    // works when the actor uses a default sheet and no core.sheetClass flag is stored.
    const sheetClassFlag = actor.getFlag?.("core", "sheetClass");
    const runtimeSheetName = actor.sheet?.constructor?.name ?? "";
    const runtimeSheetId = actor.sheet?.id ?? "";
    const isNpcSheet =
      sheetClassFlag === "sta.STANPCSheet2e" ||
      sheetClassFlag === "sta-utils.LcarsNPCSheet2e" ||
      runtimeSheetName === "STANPCSheet2e" ||
      runtimeSheetName === "LcarsNPCSheet2e" ||
      runtimeSheetId.startsWith("STANPCSheet2e") ||
      runtimeSheetId.startsWith("LcarsNPCSheet2e");
    if (isNpcSheet) return false;

    // Check if actor has stress.max = 0
    const maxStress = Number(actor.system?.stress?.max ?? 0);
    if (maxStress === 0) return false;

    return true;
  } catch (_) {
    return false;
  }
}

/**
 * Installs the stress monitoring hook. When a character's stress reaches or exceeds
 * their maximum stress, a "Fatigued" trait is automatically added. When stress drops
 * below maximum, the trait is removed.
 */
export function installStressMonitoringHook() {
  if (_staStressMonitoringHookInstalled) return;
  _staStressMonitoringHookInstalled = true;

  Hooks.on("updateActor", (actor, changes) => {
    try {
      // Only monitor character actors
      if (actor?.type !== "character") return;

      // Check if stress value changed
      const stressValueChanged =
        foundry.utils.getProperty(changes, "system.stress.value") !== undefined;
      if (!stressValueChanged) return;

      // Use player-first responsibility: owning player handles if online, otherwise GM
      const shouldHandle = shouldCurrentUserHandleFatigue(actor);
      if (!shouldHandle) return;

      // Prevent concurrent operations on the same actor
      const actorId = actor.id;
      if (_fatigueOperationInProgress.has(actorId)) return;

      // Check if this actor can experience fatigue (not NPC, stress.max > 0)
      const canFatigue = canExperienceFatigue(actor);

      const currentStress = Number(actor.system?.stress?.value ?? 0);
      const maxStress = Number(actor.system?.stress?.max ?? 0);
      const isFatigued = canFatigue && currentStress >= maxStress;
      const existingFatiguedTrait = findFatiguedTrait(actor);

      // If fatigued but no trait exists, create it
      if (isFatigued && !existingFatiguedTrait) {
        _fatigueOperationInProgress.add(actorId);
        void (async () => {
          try {
            // Double-check no trait was created by another client in the meantime
            await new Promise((r) => setTimeout(r, 50));
            const recheck = findFatiguedTrait(actor);
            if (recheck) {
              return;
            }
            await createFatiguedTrait(actor);
          } catch (_) {
            // trait creation may fail if actor was deleted
          } finally {
            _fatigueOperationInProgress.delete(actorId);
          }
        })();
        return;
      }

      // If not fatigued (or can't fatigue) but any fatigue trait exists, delete ALL of them
      // This guards against orphaned fatigue traits
      if (!isFatigued && existingFatiguedTrait) {
        _fatigueOperationInProgress.add(actorId);
        void (async () => {
          try {
            await deleteAllFatigueTraits(actor);
          } catch (_) {
            // trait deletion may fail
          } finally {
            _fatigueOperationInProgress.delete(actorId);
          }
        })();
        return;
      }
    } catch (_) {
      // stress hook should never throw
    }
  });
}
