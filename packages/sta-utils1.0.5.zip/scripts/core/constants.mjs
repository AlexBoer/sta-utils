export const MODULE_ID = "sta-utils";
