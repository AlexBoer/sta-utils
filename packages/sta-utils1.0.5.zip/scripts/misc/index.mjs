// Miscellaneous standalone hooks
export {
  AMBIENT_AUDIO_SELECTION_ONLY_SETTING,
  installAmbientAudioSelectionListenerPatch,
  setPlayerAmbientAudioSelectionOnlyEnabled,
} from "./ambient-audio-patch.mjs";
export { installMacroActorImageHook } from "./macro-actor-image.mjs";
