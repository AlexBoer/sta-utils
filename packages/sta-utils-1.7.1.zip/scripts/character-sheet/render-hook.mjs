/**
 * Render Application V2 Hook — sta-utils dispatcher
 *
 * Registers the renderApplicationV2 hook and delegates to sta-utils feature
 * modules for fatigue, dice pool, info buttons, and trait checkbox enhancements.
 *
 * @module hooks/renderAppV2/hook
 */

import { installDicePoolFatigueNotice } from "../fatigue/dice-pool-fatigue-notice.mjs";
import { installDicePoolBroadcast } from "../dice-pool-monitor/dice-pool-broadcast.mjs";
import { installFatiguedAttributeDisplay } from "../fatigue/fatigued-attribute-display.mjs";
import {
  isFatigueEnabled,
  isActionChooserEnabled,
  isActionChooserAsTabEnabled,
  isPersonalThreatEnabled,
  shouldShowItemEditButtons,
} from "../core/settings.mjs";
import { MODULE_ID } from "../core/constants.mjs";
import {
  installStressInfoButton,
  installDeterminationInfoButton,
  installValuesInfoButton,
  installTalentsInfoButton,
  installFocusesInfoButton,
  installTraitsInfoButton,
  installInjuriesInfoButton,
  installLogsInfoButton,
  installMilestonesInfoButton,
  installDirectiveInfoButton,
} from "./section-info-buttons.mjs";
import { installChooseAttributeButtons } from "../fatigue/trait-fatigue-buttons.mjs";
import { installTraitFatigueCheckbox } from "../fatigue/trait-fatigue-checkbox.mjs";
import { disableItemTooltips } from "../disable-tooltips/index.mjs";
import { actionChooser } from "../action-chooser/index.mjs";
import { t } from "../core/i18n.mjs";

import { installMobileMode } from "../mobile-sheet/mobile-mode.mjs";
import { installLcarsSheetMode } from "../lcars-sheet/lcars-mode.mjs";
import { installConfigureStressBarButton } from "../personal-threat/index.mjs";

// ─────────────────────────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Wrap a ContextMenu entry for compatibility with both Foundry v13
 * (`name`/`condition`/`callback`) and v14+ (`label`/`visible`/`onClick`).
 *
 * @param {{ label: string, icon?: string, condition?: Function, callback: Function }} e
 * @returns {object}
 */
function _compatEntry({ label, icon, condition, callback }) {
  if (game.release.generation >= 14) {
    return {
      label,
      icon,
      ...(condition != null ? { visible: condition } : {}),
      onClick: (_event, target) => callback(target),
    };
  }
  return {
    name: label,
    icon,
    ...(condition != null ? { condition } : {}),
    callback,
  };
}

/**
 * Force-close stale item description tooltips when the pointer is no longer
 * directly over an item name element.
 *
 * @param {HTMLElement} root - Render root for the sheet window.
 */
function installStrictItemTooltipHover(root) {
  if (!root || root.dataset.staStrictTooltipInit === "1") return;
  root.dataset.staStrictTooltipInit = "1";

  const selector = ".item-name[data-tooltip]";
  const closestMatch = (node) => {
    const element = node instanceof Element ? node : null;
    return element?.closest?.(selector) ?? null;
  };

  // Deactivate only when the pointer exits the currently hovered item-name.
  root.addEventListener("pointerout", (event) => {
    const from = closestMatch(event.target);
    if (!from) return;

    const to = closestMatch(event.relatedTarget);
    if (from === to) return;

    if (game.tooltip?.element === from) game.tooltip.deactivate();
  });

  root.addEventListener("pointerleave", () => {
    const activeElement = game.tooltip?.element;
    if (activeElement?.matches?.(selector)) game.tooltip.deactivate();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Dialogs
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle dialog rendering (Dice Pool dialogs).
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 * @param {object} context - The render context.
 */
function handleDialogRender(app, root, context) {
  if (isFatigueEnabled()) {
    try {
      installDicePoolFatigueNotice(app, root, context);
    } catch (_) {
      // ignore
    }
  }

  try {
    installDicePoolBroadcast(app, root, context);
  } catch (_) {
    // ignore
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Character Sheets
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle STA character sheet rendering.
 * Installs fatigue display, info buttons, and choose-attribute buttons.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
// ─────────────────────────────────────────────────────────────────────────────
// Handler: Mobile Character Sheet
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle MobileCharacterSheet2e rendering.
 * Installs collapsible sections, context menus, and create-button relocation.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleMobileSheetRender(app, root) {
  if (!app?.id?.startsWith("MobileCharacterSheet2e")) return;
  try {
    installMobileMode(app, root);
  } catch (_) {
    // ignore
  }

  try {
    installStrictItemTooltipHover(root);
  } catch (_) {
    // ignore
  }

  const actor = app.actor;
  if (!actor || actor.type !== "character") return;

  try {
    applyItemEditButtonMode(root);
  } catch (_) {
    // ignore
  }

  try {
    installInlineItemEditButtons(root, actor);
  } catch (_) {
    // ignore
  }

  if (isFatigueEnabled()) {
    try {
      installFatiguedAttributeDisplay(root, actor);
    } catch (_) {
      // ignore
    }
    try {
      installChooseAttributeButtons(root, actor, app);
    } catch (_) {
      // ignore
    }
  }

  if (isActionChooserEnabled()) {
    try {
      installMobileActionChooserTab(app, root, actor);
    } catch (_) {
      // ignore
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: LCARS Character Sheet (bespoke)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle LcarsCharacterSheet2e rendering.
 * Installs collapsible listeners, context menus, and LCARS theme picker.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleLcarsSheetRender(app, root) {
  if (
    !app?.id?.startsWith("LcarsCharacterSheet2e") &&
    !app?.id?.startsWith("LcarsSupportingSheet2e") &&
    !app?.id?.startsWith("LcarsNPCSheet2e") &&
    !app?.id?.startsWith("LcarsStarshipSheet2e") &&
    !app?.id?.startsWith("LcarsSmallCraftSheet2e")
  )
    return;
  try {
    installLcarsSheetMode(app, root);
  } catch (_) {
    // ignore
  }

  try {
    applyItemEditButtonMode(root);
  } catch (_) {
    // ignore
  }

  const actor = app.actor;

  try {
    installInlineItemEditButtons(root, actor);
  } catch (_) {
    // ignore
  }

  if (game.user?.isGM && actor) {
    try {
      installLcarsTokenLinkToggleButton(app, root, actor);
    } catch (_) {
      // ignore
    }
  }

  if (!actor || (actor.type !== "character" && actor.type !== "npc")) return;

  if (game.user?.isGM) {
    try {
      installLcarsSheetSwitcherButton(app, root, actor);
    } catch (_) {
      // ignore
    }
  }

  const isNpcOnNpcSheet = app?.id?.startsWith("LcarsNPCSheet2e");

  if (isNpcOnNpcSheet && isPersonalThreatEnabled()) {
    try {
      installConfigureStressBarButton(root, actor);
    } catch (_) {
      // ignore
    }
  }

  if (isFatigueEnabled() && !isNpcOnNpcSheet) {
    try {
      installFatiguedAttributeDisplay(root, actor);
    } catch (_) {
      // ignore
    }
    try {
      installChooseAttributeButtons(root, actor, app);
    } catch (_) {
      // ignore
    }
  }

  try {
    installStressInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installDeterminationInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installValuesInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installTalentsInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installFocusesInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installTraitsInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installInjuriesInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installLogsInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installMilestonesInfoButton(root);
  } catch (_) {
    // ignore
  }
  try {
    installDirectiveInfoButton(root);
  } catch (_) {
    // ignore
  }

  if (isFatigueEnabled() && !isNpcOnNpcSheet) {
    try {
      installChooseAttributeButtons(root, actor, app);
    } catch (_) {
      // ignore
    }
  }

  if (isActionChooserEnabled()) {
    if (isActionChooserAsTabEnabled()) {
      try {
        installActionChooserTab(app, root, actor);
      } catch (_) {
        // ignore
      }
    } else {
      try {
        installActionChooserButton(root, actor);
      } catch (_) {
        // ignore
      }
    }
  }
}

const LCARS_CHARACTER_SHEET_OPTIONS = {
  main: {
    className: "sta-utils.LcarsCharacterSheet2e",
    appPrefix: "LcarsCharacterSheet2e",
    labelKey: "sta-utils.lcarsSheetSwitcher.main",
  },
  supporting: {
    className: "sta-utils.LcarsSupportingSheet2e",
    appPrefix: "LcarsSupportingSheet2e",
    labelKey: "sta-utils.lcarsSheetSwitcher.supporting",
  },
  npc: {
    className: "sta-utils.LcarsNPCSheet2e",
    appPrefix: "LcarsNPCSheet2e",
    labelKey: "sta-utils.lcarsSheetSwitcher.npc",
  },
};

function _getCurrentLcarsSheetKey(app, actor) {
  const appId = String(app?.id ?? "");
  if (appId.startsWith("LcarsCharacterSheet2e")) return "main";
  if (appId.startsWith("LcarsSupportingSheet2e")) return "supporting";
  if (appId.startsWith("LcarsNPCSheet2e")) return "npc";

  const sheetClassFlag = String(actor?.getFlag?.("core", "sheetClass") ?? "");
  if (sheetClassFlag === LCARS_CHARACTER_SHEET_OPTIONS.main.className) {
    return "main";
  }
  if (sheetClassFlag === LCARS_CHARACTER_SHEET_OPTIONS.supporting.className) {
    return "supporting";
  }
  if (sheetClassFlag === LCARS_CHARACTER_SHEET_OPTIONS.npc.className) {
    return "npc";
  }

  return "main";
}

function _getLcarsNameRow(root) {
  return root?.querySelector?.(
    ".top-right-column .name-row, .right-column .name-row",
  );
}

function _getTokenLinkContext(app, actor) {
  const tokenDoc =
    app?.token?.document ?? (actor?.isToken ? actor?.token : null);
  if (tokenDoc) {
    return {
      linked: !!tokenDoc.actorLink,
      scope: "token",
      update: async (linked) => tokenDoc.update({ actorLink: linked }),
    };
  }

  return {
    linked: !!actor?.prototypeToken?.actorLink,
    scope: "prototype",
    update: async (linked) =>
      actor.update({ "prototypeToken.actorLink": linked }),
  };
}

function _renderTokenLinkButtonState(button, linked, scope) {
  const titleKey = linked
    ? scope === "token"
      ? "sta-utils.lcarsTokenLinkToggle.titleLinkedToken"
      : "sta-utils.lcarsTokenLinkToggle.titleLinkedPrototype"
    : scope === "token"
      ? "sta-utils.lcarsTokenLinkToggle.titleUnlinkedToken"
      : "sta-utils.lcarsTokenLinkToggle.titleUnlinkedPrototype";
  button.title = t(titleKey);
  button.innerHTML = linked
    ? '<i class="fa-solid fa-link"></i>'
    : '<i class="fa-solid fa-link-slash"></i>';
}

function installLcarsTokenLinkToggleButton(app, root, actor) {
  const appId = String(app?.id ?? "");
  const isLcarsSheet =
    appId.startsWith("LcarsCharacterSheet2e") ||
    appId.startsWith("LcarsSupportingSheet2e") ||
    appId.startsWith("LcarsNPCSheet2e") ||
    appId.startsWith("LcarsStarshipSheet2e") ||
    appId.startsWith("LcarsSmallCraftSheet2e");
  if (!isLcarsSheet) return;

  const nameRow = _getLcarsNameRow(root);
  if (!nameRow) return;

  let button = nameRow.querySelector(".sta-lcars-token-link-btn");
  if (!button) {
    button = document.createElement("button");
    button.type = "button";
    button.className = "sta-lcars-theme-btn sta-lcars-token-link-btn";
    button.setAttribute(
      "aria-label",
      t("sta-utils.lcarsTokenLinkToggle.ariaLabel"),
    );

    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();

      const context = _getTokenLinkContext(app, actor);
      const nextLinked = !context.linked;

      await context.update(nextLinked);
      _renderTokenLinkButtonState(button, nextLinked, context.scope);

      ui.notifications.info(
        nextLinked
          ? context.scope === "token"
            ? t("sta-utils.lcarsTokenLinkToggle.linkedToken")
            : t("sta-utils.lcarsTokenLinkToggle.linkedPrototype")
          : context.scope === "token"
            ? t("sta-utils.lcarsTokenLinkToggle.unlinkedToken")
            : t("sta-utils.lcarsTokenLinkToggle.unlinkedPrototype"),
      );
    });
  }

  const context = _getTokenLinkContext(app, actor);
  _renderTokenLinkButtonState(button, context.linked, context.scope);

  const switcherButton = nameRow.querySelector(".sta-lcars-sheet-switch-btn");
  if (switcherButton?.parentElement === nameRow) {
    switcherButton.insertAdjacentElement("afterend", button);
  } else {
    const themeButton = nameRow.querySelector(".sta-lcars-theme-btn");
    if (themeButton?.parentElement === nameRow) {
      themeButton.insertAdjacentElement("afterend", button);
    } else {
      nameRow.appendChild(button);
    }
  }
}

function installLcarsSheetSwitcherButton(app, root, actor) {
  const appId = String(app?.id ?? "");
  const isCharacterLcarsSheet =
    appId.startsWith("LcarsCharacterSheet2e") ||
    appId.startsWith("LcarsSupportingSheet2e") ||
    appId.startsWith("LcarsNPCSheet2e");
  if (!isCharacterLcarsSheet) return;

  if (String(actor?.type ?? "") !== "character") return;

  const nameRow = _getLcarsNameRow(root);
  if (!nameRow) return;
  if (nameRow.querySelector(".sta-lcars-sheet-switch-btn")) return;

  const button = document.createElement("button");
  button.type = "button";
  button.className = "sta-lcars-theme-btn sta-lcars-sheet-switch-btn";
  button.title = t("sta-utils.lcarsSheetSwitcher.buttonTitle");
  button.innerHTML = '<i class="fa-solid fa-users-gear"></i>';

  button.addEventListener("click", async (event) => {
    event.preventDefault();
    event.stopPropagation();

    const currentKey = _getCurrentLcarsSheetKey(app, actor);
    const selection = await foundry.applications.api.DialogV2.wait({
      window: {
        title: t("sta-utils.lcarsSheetSwitcher.dialogTitle"),
        icon: "fa-solid fa-users-gear",
      },
      position: {
        width: 760,
        height: "auto",
      },
      content: `<p>${t("sta-utils.lcarsSheetSwitcher.dialogPrompt")}</p>`,
      classes: [
        "sta-utils",
        "sta-utils-ms-lcars",
        "sta-lcars-sheet-switcher-dialog",
      ],
      buttons: [
        {
          action: "main",
          label: t("sta-utils.lcarsSheetSwitcher.main"),
          default: currentKey === "main",
        },
        {
          action: "supporting",
          label: t("sta-utils.lcarsSheetSwitcher.supporting"),
          default: currentKey === "supporting",
        },
        {
          action: "npc",
          label: t("sta-utils.lcarsSheetSwitcher.npc"),
          default: currentKey === "npc",
        },
        {
          action: "cancel",
          label: game.i18n.localize("Cancel"),
        },
      ],
      default: "cancel",
    });

    const selectedKey = String(selection ?? "");
    if (!selectedKey || selectedKey === "cancel") return;

    const selectedOption = LCARS_CHARACTER_SHEET_OPTIONS[selectedKey];
    if (!selectedOption) return;
    if (selectedKey === currentKey) return;

    await actor.setFlag("core", "sheetClass", selectedOption.className);
    ui.notifications.info(
      t("sta-utils.lcarsSheetSwitcher.changed").replace(
        "{label}",
        t(selectedOption.labelKey),
      ),
    );

    await app.close();
    actor.sheet?.render(true);
  });

  const themeButton = nameRow.querySelector(".sta-lcars-theme-btn");
  if (themeButton?.parentElement === nameRow) {
    themeButton.insertAdjacentElement("afterend", button);
  } else {
    nameRow.appendChild(button);
  }
}

function handleCharacterSheetRender(app, root) {
  // MobileCharacterSheet2e and LcarsCharacterSheet2e have their own handlers.
  if (app?.id?.startsWith("MobileCharacterSheet2e")) return;
  if (app?.id?.startsWith("LcarsCharacterSheet2e")) return;
  if (app?.id?.startsWith("LcarsSupportingSheet2e")) return;
  if (app?.id?.startsWith("LcarsNPCSheet2e")) return;

  if (
    !app?.id?.startsWith("STACharacterSheet2e") &&
    !app?.id?.startsWith("STASupportingSheet2e") &&
    !app?.id?.startsWith("STACharacterSheet-") &&
    !app?.id?.startsWith("STANPCSheet2e")
  )
    return;

  const actor = app.actor;
  if (!actor || (actor.type !== "character" && actor.type !== "npc")) return;

  try {
    installStrictItemTooltipHover(root);
  } catch (_) {
    // ignore
  }

  try {
    applyItemEditButtonMode(root);
  } catch (_) {
    // ignore
  }

  try {
    installInlineItemEditButtons(root, actor);
  } catch (_) {
    // ignore
  }

  const isNpcOnNpcSheet = app?.id?.startsWith("STANPCSheet2e");

  if (isNpcOnNpcSheet && isPersonalThreatEnabled()) {
    try {
      installConfigureStressBarButton(root, actor);
    } catch (_) {
      // ignore
    }
  }

  if (isFatigueEnabled() && !isNpcOnNpcSheet) {
    try {
      installFatiguedAttributeDisplay(root, actor);
    } catch (_) {
      // ignore
    }
  }

  try {
    installStressInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installDeterminationInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installValuesInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installTalentsInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installFocusesInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installTraitsInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installInjuriesInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installLogsInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installMilestonesInfoButton(root);
  } catch (_) {
    // ignore
  }

  try {
    installDirectiveInfoButton(root);
  } catch (_) {
    // ignore
  }

  if (isFatigueEnabled() && !isNpcOnNpcSheet) {
    try {
      installChooseAttributeButtons(root, actor, app);
    } catch (_) {
      // ignore
    }
  }

  if (isActionChooserEnabled()) {
    if (isActionChooserAsTabEnabled()) {
      try {
        installActionChooserTab(app, root, actor);
      } catch (_) {
        // ignore
      }
    } else {
      try {
        installActionChooserButton(root, actor);
      } catch (_) {
        // ignore
      }
    }
  }
}

/**
 * Toggle CSS mode that reveals native item edit controls on sheet rows.
 *
 * @param {HTMLElement} root
 */
function applyItemEditButtonMode(root) {
  const show = shouldShowItemEditButtons();
  const selector = ".character-sheet, .starship-sheet, .smallcraft-sheet";
  const sheets = [];
  if (root?.matches?.(selector)) sheets.push(root);
  for (const el of root?.querySelectorAll?.(selector) ?? []) sheets.push(el);
  if (!sheets.length) return;
  for (const sheet of sheets) {
    sheet.classList.toggle("sta-utils-show-item-edit-buttons", show);
  }
}

/**
 * Adds a right-side edit button to each item row when enabled in client settings.
 * The button opens the item's sheet directly.
 *
 * @param {HTMLElement} root
 * @param {Actor} actor
 */
function installInlineItemEditButtons(root, actor) {
  // Remove previously injected buttons on re-render.
  root
    ?.querySelectorAll?.(".control.sta-utils-inline-item-edit")
    ?.forEach?.((el) => el.remove());

  if (!shouldShowItemEditButtons()) return;

  const rows = root?.querySelectorAll?.(".row.entry[data-item-id]");
  if (!rows?.length) return;

  for (const row of rows) {
    const itemId = String(row?.dataset?.itemId ?? "");
    if (!itemId) continue;

    const item = actor?.items?.get?.(itemId);
    if (!item?.sheet) continue;

    // If a native edit control is already visible, don't add a duplicate.
    const nativeEdit = row.querySelector?.(
      '.control .edit[data-action="onItemEdit"]',
    );
    if (nativeEdit && nativeEdit.offsetParent !== null) continue;

    const control = document.createElement("div");
    control.className = "control sta-utils-inline-item-edit";

    const button = document.createElement("a");
    button.className = "edit sta-utils-inline-item-edit-btn";
    button.href = "#";
    button.title = t("sta-utils.compactMenu.editItem");
    button.setAttribute("aria-label", t("sta-utils.compactMenu.editItem"));
    button.innerHTML = '<i class="fas fa-edit"></i>';

    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await item.sheet.render(true);
      item.sheet.bringToFront?.();
    });

    control.appendChild(button);
    row.appendChild(control);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Mobile Action Chooser Tab (popup trigger)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Inject an "Actions" tab link into the mobile sheet tab bar.
 * Clicking it opens the popup (windowed) action chooser instead of
 * switching to a page panel — the tab has no associated content pane.
 *
 * @param {Application} sheetApp - The MobileCharacterSheet2e instance.
 * @param {HTMLElement} root     - The root element of the character sheet.
 * @param {Actor}       actor    - The actor for this sheet.
 */
function installMobileActionChooserTab(sheetApp, root, actor) {
  const tabNav = root?.querySelector?.(".mobile-tabs");
  if (!tabNav) return;

  // Don't add the tab link more than once
  if (tabNav.querySelector('[data-tab="actions"]')) return;

  const tabLink = document.createElement("a");
  tabLink.className = "item sta-mobile-actions-tab";
  tabLink.dataset.tab = "actions";
  tabLink.textContent = t("sta-utils.actionChooser.tabLabel");
  const icon = document.createElement("i");
  icon.className = "fas fa-external-link-alt";
  tabLink.appendChild(icon);

  // Intercept click: open the popup action chooser, don't switch tabs
  tabLink.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    actionChooser.open("personal-conflict", { actor });
  });

  tabNav.appendChild(tabLink);
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Combat Turn Indicator on Character Profile Image
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Check if the given actor is the current combatant in the active combat
 * tracker and, if so, overlay a visual "your turn" indicator on the
 * character sheet's profile image.
 *
 * Called on every renderApplicationV2 for STA actor sheets when the action
 * chooser feature is enabled.
 *
 * @param {HTMLElement} root - The root element of the character sheet.
 * @param {Actor} actor - The actor associated with this sheet.
 */
function installTurnIndicator(root, actor) {
  const imageField = root?.querySelector?.(".top-left-column .image-field");
  if (!imageField) return;

  // Clean up any existing indicator
  imageField.classList.remove("sta-utils-active-turn");
  const existing = imageField.querySelector(".sta-utils-turn-indicator");
  if (existing) existing.remove();

  // Check active combat
  const combat = game.combat;
  if (!combat?.started) return;

  const currentCombatant = combat.combatant;
  if (!currentCombatant) return;

  // Match by actor ID — the combatant links to the actor via actorId
  const isCurrentTurn = currentCombatant.actorId === actor.id;
  if (!isCurrentTurn) return;

  // Add glow class and badge
  imageField.classList.add("sta-utils-active-turn");

  const badge = document.createElement("div");
  badge.className = "sta-utils-turn-indicator";
  badge.innerHTML = '<i class="fas fa-crosshairs"></i> YOUR TURN';
  badge.title = t("sta-utils.actionChooser.yourTurn");
  imageField.appendChild(badge);
}

/**
 * Handle turn indicator rendering for any STA actor sheet.
 * Extracts the actor and delegates to installTurnIndicator.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleTurnIndicator(app, root) {
  const actor = app?.actor;
  if (game.user?.isGM && actor) {
    try {
      installLcarsTokenLinkToggleButton(app, root, actor);
    } catch (_) {
      // ignore
    }
  }
  if (!actor) return;
  // Apply to character-type and NPC actors (not starships/smallcraft)
  if (actor.type !== "character" && actor.type !== "npc") return;
  installTurnIndicator(root, actor);
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Action Chooser Button
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Inject the "Conflict Actions" button below the Perform Task / Roll Reputation
 * buttons on the character sheet.
 *
 * @param {HTMLElement} root - The root element of the character sheet.
 * @param {Actor} actor - The actor associated with this character sheet.
 */
function installActionChooserButton(root, actor) {
  const buttonsDiv = root?.querySelector?.(".bottom-left-column .buttons");
  if (!buttonsDiv) return;

  // Don't add the button if it already exists
  if (buttonsDiv.querySelector(".sta-utils-action-chooser-btn")) return;

  const btn = document.createElement("div");
  btn.className = "check-button btn2 sta-utils-action-chooser-btn";
  btn.textContent = t("sta-utils.actionChooser.conflictActionsButton");
  btn.addEventListener("click", (ev) => {
    ev.preventDefault();
    actionChooser.open("personal-conflict", { actor });
  });

  buttonsDiv.appendChild(btn);
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Action Chooser Tab (Embedded)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Inject the action chooser as a tab on the character sheet.
 * Uses the proper Foundry v13 ApplicationV2 pipeline: an EmbeddedActionChooserApp
 * renders frameless into a container div inside the tab pane. Foundry's render
 * pipeline manages the DOM, so switching action sets never blanks the tab.
 *
 * When embedded, the actor is locked (no actor dropdown) but ship selection
 * remains available.
 *
 * @param {Application} sheetApp - The character sheet ApplicationV2 instance.
 * @param {HTMLElement} root - The root element of the character sheet.
 * @param {Actor} actor - The actor associated with this character sheet.
 */
async function installActionChooserTab(sheetApp, root, actor) {
  const tabNav = root?.querySelector?.(".sheet-tabs.tabs");
  const sheetBody = root?.querySelector?.(".sheet-body");
  if (!tabNav || !sheetBody) return;

  // Add the tab header if not already present
  let tabLink = tabNav.querySelector('[data-tab="actions"]');
  if (!tabLink) {
    tabLink = document.createElement("a");
    tabLink.className = "item";
    tabLink.dataset.group = "primary";
    tabLink.dataset.action = "tab";
    tabLink.dataset.tab = "actions";
    tabLink.textContent = t("sta-utils.actionChooser.tabLabel");
    tabNav.appendChild(tabLink);
  }

  // Add the tab pane if not already present
  let tabPane = sheetBody.querySelector('[data-tab="actions"][name="actions"]');
  if (!tabPane) {
    tabPane = document.createElement("div");
    tabPane.className = "tab";
    tabPane.dataset.group = "primary";
    tabPane.dataset.tab = "actions";
    tabPane.setAttribute("name", "actions");
    // The EmbeddedActionChooserApp will insert its own <section> element here
    sheetBody.appendChild(tabPane);
  }

  // Check if "actions" was the active tab — Foundry stores this in the sheet's
  // tabGroups map. Since our tab is injected after Foundry's render pass, it
  // won't have been activated automatically. We need to manually sync.
  const activeGroup = sheetApp?.tabGroups?.primary;
  if (activeGroup === "actions") {
    // Mark the tab link active
    tabNav
      .querySelectorAll('.item[data-group="primary"]')
      .forEach((link) =>
        link.classList.toggle("active", link.dataset.tab === "actions"),
      );
    // Deactivate all sibling panes, activate ours
    sheetBody
      .querySelectorAll('.tab[data-group="primary"]')
      .forEach((p) => p.classList.remove("active"));
    tabPane.classList.add("active");
  }

  // Render the embedded action chooser into the tab pane
  try {
    await actionChooser.renderEmbed(tabPane, actor);
  } catch (err) {
    console.error("sta-utils | Failed to render embedded action chooser", err);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Starship / Small Craft Sheets — Shield Breakthrough Markers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Inject breakthrough-marker divs into #bar-shields-renderer at the correct
 * pip boundaries (after floor(max×0.5) and floor(max×0.25)).
 *
 * The system rebuilds the bar DOM via innerHTML='' on every shield click and
 * again on every full render.  We therefore set up a MutationObserver so that
 * any time the bar's children change we re-inject immediately after — keeping
 * the markers in sync without requiring any additional click-handler overrides.
 *
 * Only runs when the root contains .sta-lcars (LCARS theme active).
 *
 * @param {HTMLElement} root - The sheet root element.
 */
function _injectShieldBreakthroughMarkers(root) {
  const bar = root.querySelector("#bar-shields-renderer");
  if (!bar) return;

  // Width of each injected marker in px.  Each marker is a real flex child,
  // so pip widths must shrink proportionally to keep the total at 100%.
  const MARKER_WIDTH_PX = 7;

  function inject() {
    // Remove any markers we placed previously and restore original pip widths.
    bar
      .querySelectorAll(".sta-lcars-shield-breakthrough")
      .forEach((m) => m.remove());

    const maxInput = root.querySelector("#max-shields");
    const max = parseInt(maxInput?.value ?? 0, 10);
    if (!max || max < 2) return;

    // Breakthrough positions: after pip floor(max × 0.5) and floor(max × 0.25).
    const positions = [Math.floor(max * 0.5), Math.floor(max * 0.25)].filter(
      (pos) => pos > 0 && pos < max,
    );

    if (positions.length === 0) return;

    // Shrink every pip width to compensate for the space the markers take.
    // Original width = calc(100% / max).  New width = calc((100% - N*7px) / max).
    const pipWidth = `calc((100% - ${positions.length * MARKER_WIDTH_PX}px) / ${max})`;
    bar.querySelectorAll(".box.shields").forEach((pip) => {
      pip.style.width = pipWidth;
    });

    // Insert each marker as a real flex child immediately after pip N
    // (shields-{pos}), so the layout naturally makes room for it.
    for (const pos of positions) {
      const anchor = bar.querySelector(`#shields-${pos}`);
      if (!anchor) continue;
      const marker = document.createElement("div");
      marker.className = "sta-lcars-shield-breakthrough";
      anchor.insertAdjacentElement("afterend", marker);
    }
  }

  // Initial injection (bar is already populated by the system's _onRender).
  inject();

  // Watch for subsequent bar rebuilds (shield pip clicks rebuild innerHTML).
  // Guard against re-entrancy: skip MutationObserver callbacks that are
  // triggered solely by our own marker insertions.
  if (bar._lcarsBreakthroughObserver) return;
  const observer = new MutationObserver((mutations) => {
    const onlyOurChanges = mutations.every(
      (m) =>
        [...m.addedNodes].every((n) =>
          n.classList?.contains("sta-lcars-shield-breakthrough"),
        ) &&
        [...m.removedNodes].every((n) =>
          n.classList?.contains("sta-lcars-shield-breakthrough"),
        ),
    );
    if (!onlyOurChanges) inject();
  });
  observer.observe(bar, { childList: true });
  bar._lcarsBreakthroughObserver = observer;
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Starship / Small Craft Sheets — Reserve Power System Glow & Menu
// ─────────────────────────────────────────────────────────────────────────────

/** Tracks the current ContextMenu attached to starship system rows. */
let _reservePowerContextMenu = null;

/**
 * Highlight the system that reserve power is routed to on starship and
 * small-craft character sheets.  Adds a CSS class to the matching system
 * row so it receives a glowing outline, and removes it from all others.
 *
 * Also installs a right-click context menu on each system name that lets
 * the user route (or clear) reserve power to that system.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleStarshipSheetRender(app, root) {
  const actor = app?.actor;
  if (!actor) return;
  if (actor.type !== "starship" && actor.type !== "smallcraft") return;

  // LCARS starship/smallcraft sheets have their own strict tooltip handling.
  const appId = String(app?.id ?? "");
  if (!appId.startsWith("Lcars")) {
    try {
      installStrictItemTooltipHover(root);
    } catch (_) {
      // ignore
    }
  }

  const systemsBlock = root?.querySelector?.(".systems-block");
  if (!systemsBlock) return;

  // Read the routed system from our system field
  const reservePowerSystem =
    actor.system?.reservePowerSystem ??
    actor.getFlag(MODULE_ID, "reservePowerSystem") ??
    null;
  const hasReservePower = actor.system?.reservepower ?? false;

  // Iterate every system row and toggle the glow class
  systemsBlock.querySelectorAll(".stat.row").forEach((row) => {
    // The system checkbox id is like "communications.selector"
    const checkbox = row.querySelector(".selector.system");
    if (!checkbox) return;
    const systemKey = checkbox.id?.replace(".selector", "") ?? "";

    if (hasReservePower && reservePowerSystem === systemKey) {
      row.classList.add("sta-utils-reserve-power-routed");
    } else {
      row.classList.remove("sta-utils-reserve-power-routed");
    }
  });

  // Install right-click context menu on system name labels
  _installReservePowerContextMenu(systemsBlock, actor);

  // Inject shield breakthrough markers on LCARS sheets only.
  if (root.querySelector?.(".starship-sheet.sta-lcars-sheet")) {
    _injectShieldBreakthroughMarkers(root);
  }
}

/**
 * Helper — extract the system key from a context-menu target element.
 * The target is the `.text.list-entry` div; we walk up to the `.stat.row`
 * parent and read the checkbox id (e.g. "communications.selector").
 *
 * @param {HTMLElement} target - The right-clicked element.
 * @returns {string|null} The system key, or null if not found.
 */
function _systemKeyFromTarget(target) {
  const row = target?.closest?.(".stat.row");
  if (!row) return null;
  const checkbox = row.querySelector(".selector.system");
  if (!checkbox) return null;
  return checkbox.id?.replace(".selector", "") || null;
}

/**
 * Install a Foundry ContextMenu on the system name labels inside the
 * systems block of a starship / small-craft sheet.
 *
 * Menu entries:
 *  • "Route Reserve Power Here" — sets the reservePowerSystem flag to
 *    the right-clicked system (only shown when reserve power is available).
 *  • "Clear Reserve Power Routing" — clears the flag (only shown when a
 *    system is currently routed).
 *
 * @param {HTMLElement} systemsBlock - The `.systems-block` container.
 * @param {Actor} actor - The starship / small-craft actor.
 */
function _installReservePowerContextMenu(systemsBlock, actor) {
  // Tear down any previous instance so we don't stack listeners
  try {
    if (_reservePowerContextMenu?.element) {
      _reservePowerContextMenu.close();
    }
  } catch (_) {
    /* ignore */
  } finally {
    _reservePowerContextMenu = null;
  }

  /** @type {ContextMenuEntry[]} */
  const menuItems = [
    _compatEntry({
      label: t("sta-utils.reservePowerMenu.routeHere"),
      icon: '<i class="fas fa-bolt"></i>',
      condition: () => {
        return actor.system?.reservepower ?? false;
      },
      callback: async (target) => {
        const el =
          target instanceof HTMLElement
            ? target
            : target?.[0] instanceof HTMLElement
              ? target[0]
              : null;
        const systemKey = _systemKeyFromTarget(el);
        if (!systemKey) return;
        await actor.update({ "system.reservePowerSystem": systemKey });
      },
    }),
    _compatEntry({
      label: t("sta-utils.reservePowerMenu.clearRouting"),
      icon: '<i class="fas fa-power-off"></i>',
      condition: () => {
        const current =
          actor.system?.reservePowerSystem ??
          actor.getFlag(MODULE_ID, "reservePowerSystem") ??
          null;
        return current != null;
      },
      callback: async (target) => {
        await actor.update({ "system.reservePowerSystem": null });
      },
    }),
  ];

  _reservePowerContextMenu = new foundry.applications.ux.ContextMenu(
    systemsBlock,
    ".stat.row .text.list-entry",
    menuItems,
    { fixed: true, jQuery: false },
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Item Sheets
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle STA trait item sheet rendering.
 * Installs the fatigued checkbox on trait item sheets.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleItemSheetRender(app, root) {
  if (!isFatigueEnabled()) return;

  const item = app?.item ?? null;
  if (!item || item.type !== "trait") return;

  try {
    installTraitFatigueCheckbox(root, item);
  } catch (_) {
    // ignore
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Extended Task Sheets
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle STA extended task sheet rendering.
 * Installs LCARS mode when enabled.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleExtendedTaskSheetRender(app, root) {
  const actor = app?.actor;
  if (!actor || actor.type !== "extendedtask") return;
}

// ─────────────────────────────────────────────────────────────────────────────
// Handler: Scene Traits Sheets
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Handle STA scene traits sheet rendering.
 * Installs LCARS mode when enabled.
 *
 * @param {Application} app - The application being rendered.
 * @param {HTMLElement} root - The root element.
 */
function handleSceneTraitsSheetRender(app, root) {
  const actor = app?.actor;
  if (!actor || actor.type !== "scenetraits") return;
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Hook
// ─────────────────────────────────────────────────────────────────────────────

/** Guard to prevent duplicate hook installation. */
let _staUtilsRenderApplicationV2HookInstalled = false;

/** Guard for combat hooks. */
let _combatTurnHooksInstalled = false;

/**
 * Directly update the turn indicator on all open STA character / NPC sheets
 * without triggering a full re-render (which would fire other modules' hooks
 * and can cause errors in modules that don't support Foundry v13 DOM).
 */
function _refreshOpenSheetTurnIndicators() {
  if (!isActionChooserEnabled()) return;
  for (const app of Object.values(ui.windows)) {
    const actor = app.actor ?? app.object;
    if (
      app.rendered &&
      actor &&
      (actor.type === "character" || actor.type === "npc") &&
      app.element
    ) {
      try {
        installTurnIndicator(app.element, actor);
      } catch (_) {
        // ignore
      }
    }
  }
}

/**
 * Register Foundry hooks that fire when the combat turn, round, or
 * combat itself changes, so turn indicators stay in sync.
 */
function _installCombatTurnHooks() {
  if (_combatTurnHooksInstalled) return;
  _combatTurnHooksInstalled = true;

  Hooks.on("updateCombat", (_combat, changes) => {
    if ("turn" in changes || "round" in changes || "started" in changes) {
      _refreshOpenSheetTurnIndicators();
    }
  });

  Hooks.on("deleteCombat", () => {
    _refreshOpenSheetTurnIndicators();
  });

  Hooks.on("createCombatant", () => {
    _refreshOpenSheetTurnIndicators();
  });

  Hooks.on("deleteCombatant", () => {
    _refreshOpenSheetTurnIndicators();
  });
}

/**
 * Install the main renderApplicationV2 hook for sta-utils.
 *
 * Sets up the central hook that intercepts all ApplicationV2 renders
 * in Foundry VTT and delegates to sta-utils feature handlers.
 *
 * @example
 * // Called once during module initialization
 * installRenderApplicationV2Hook();
 */
export function installRenderApplicationV2Hook() {
  if (_staUtilsRenderApplicationV2HookInstalled) return;
  _staUtilsRenderApplicationV2HookInstalled = true;

  Hooks.on("renderApplicationV2", (app, root /* HTMLElement */, context) => {
    // Early exit for non-STA applications to minimize overhead
    const appId = app?.id ?? "";
    const isStaApp =
      appId.startsWith("STACharacterSheet2e") ||
      appId.startsWith("STASupportingSheet2e") ||
      appId.startsWith("STATracker") ||
      appId.startsWith("sta-") ||
      appId.startsWith("MobileCharacterSheet2e") ||
      appId.startsWith("LcarsCharacterSheet2e") ||
      appId.startsWith("LcarsSupportingSheet2e") ||
      appId.startsWith("LcarsNPCSheet2e") ||
      appId.startsWith("LcarsStarshipSheet2e") ||
      appId.startsWith("LcarsSmallCraftSheet2e") ||
      app?.constructor?.name?.startsWith?.("STA");
    const isDialog =
      app?.constructor?.name === "DialogV2" || appId.startsWith("dialog-");
    const isItemSheet = appId.includes("ItemSheet") || app?.object?.type;

    // Skip entirely if this is clearly not an STA-related application
    if (!isStaApp && !isDialog && !isItemSheet) return;

    // Handle dialogs (Dice Pool).
    handleDialogRender(app, root, context);

    // Handle item sheet enhancements (trait fatigued checkbox).
    handleItemSheetRender(app, root);

    // Handle mobile character sheet.
    handleMobileSheetRender(app, root);

    // Handle bespoke LCARS character sheet.
    handleLcarsSheetRender(app, root);

    // Handle character sheet enhancements.
    handleCharacterSheetRender(app, root);

    // Handle starship/smallcraft sheet enhancements.
    handleStarshipSheetRender(app, root);

    // Handle extended task sheet enhancements.
    handleExtendedTaskSheetRender(app, root);

    // Handle scene traits sheet enhancements.
    handleSceneTraitsSheetRender(app, root);

    // Turn indicator on character profile image (gated behind action chooser)
    if (isActionChooserEnabled() && isStaApp) {
      try {
        handleTurnIndicator(app, root);
      } catch (_) {
        // ignore
      }
    }

    // Strip rich item-description tooltips if the user has disabled them.
    if (isStaApp) {
      try {
        disableItemTooltips(root);
      } catch (_) {
        // ignore
      }
    }
  });

  // ---- Combat hooks: refresh open sheets when the turn changes ----
  _installCombatTurnHooks();
}
